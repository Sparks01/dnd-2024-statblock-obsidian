```monsterwide
{{monster,frame,wide
## Allosaurus
*Huge Beast, *
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 57 (6d12+18)
**Speed**      :: 60 ft.
\column
**Initiative** :: +4 (18)
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 18|  +4  |  +4  |
|Dex| 18|  +4  |  +4  |
|Con| 16|  +3  |  +3  |
\column
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Int| 2|  -4  |  -4  |
|Wis| 12|  +1  |  +1  |
|Cha| 5|  -3  |  -3  |
}}
**Skills**     :: None
**Senses**      :: passive Perception 11
**Languages**   :: None
**CR**          :: 3 (700 XP; PB +2)
}}
### Actions
***Bite.*** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 17 (3d8 + 4) slashing damage. If the allosaurus moves at least 10 feet towards its target before making this attack  it gains advantage on the attack.

}}

---
*Source: A5e Monstrous Menagerie, p. 89 ([URL](https://enpublishingrpg.com/products/level-up-monstrous-menagerie-a5e))*
```