```monsterwide
{{monster,frame,wide
## Abominable Snowman
*Large Monstrosity*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 136 (16d10+48)
**Speed**      :: 40 ft. climb 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +3
**Senses**      :: passive Perception 13
**Languages**   :: Yeti
**CR**          :: 4 (PB +2)
}}
### Traits
- **Camouflage:** The yeti has advantage on Stealth checks made to hide in snowy terrain.
- **Fire Fear:** When the yeti takes fire damage, it is rattled until the end of its next turn.
- **Storm Sight:** The yetis vision is not obscured by weather conditions.
### Actions
- **Multiattack:** The yeti uses Chilling Gaze and makes two claw attacks.
- **Claw:** Melee Weapon Attack: +6 to hit, reach 10 ft., one target. Hit: 9 (2d4 + 4) slashing damage.
- **Chilling Gaze (Gaze):** One creature within 30 feet that is not immune to cold damage makes a DC 13 Constitution saving throw. On a failure  the creature takes 10 (3d6) cold damage and is paralyzed for 1 minute. It repeats the saving throw at the end of each of its turns  ending the effect on a success. If a creatures saving throw is successful or the effect ends for it  it is immune to any Chilling Gaze for 24 hours.
}}
```