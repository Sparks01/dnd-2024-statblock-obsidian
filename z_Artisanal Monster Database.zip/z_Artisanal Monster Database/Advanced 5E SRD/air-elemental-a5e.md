```monsterwide
{{monster,frame,wide
## Air Elemental
*Large elemental*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 90 (12d10+24)
**Speed**      :: 0 ft. fly 90 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Auran
**CR**          :: 5 (PB +2)
}}
### Traits
- **Air Form:** The elemental can enter and end its turn in other creatures spaces and pass through an opening as narrow as 1 inch wide without squeezing.
- **Elemental Nature:** An elemental doesnt require air, sustenance, or sleep.
### Actions
- **Multiattack:** The elemental makes two slam attacks.
- **Slam:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 14 (3d6 + 4) bludgeoning damage.
- **Whirlwind (Recharge 5-6):** The elemental takes the form of a whirlwind  flies up to half of its fly speed without provoking opportunity attacks  and then resumes its normal form. When a creature shares its space with the whirlwind for the first time during this movement  that creature makes a DC 15 Strength saving throw. On a failure  the creature is carried inside the elementals space until the whirlwind ends  taking 3 (1d6) bludgeoning damage for each 10 feet it is carried  and falls prone at the end of the movement. The whirlwind can carry one Large creature or up to four Medium or smaller creatures.
}}
```