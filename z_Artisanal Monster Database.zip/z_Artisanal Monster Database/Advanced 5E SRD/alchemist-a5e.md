```monsterwide
{{monster,frame,wide
## Alchemist
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 91 (14d8+28)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: arcana +7, investigation +7, nature +7, perception +5
**Senses**      :: passive Perception 15
**Languages**   :: any four
**CR**          :: 6 (PB +2)
}}
### Traits
- **Alchemy Schooling:** The alchemist gains their proficiency bonus and an expertise die (+1d6) on checks made with alchemists supplies.
- **Crafting:** So long as the alchemist has the required components and equipment, they are able to craft potions of up to legendary rarity and other magic items of up to very rare rarity.
- **Potion Crafter:** The alchemist has the following potions on hand:
- **Potion of climbing:** For 1 hour, the drinker gains a climb speed equal to its Speed and has advantage on Athletics checks made to climb
- **Potion of greater healing (3):** Restores 14 (4d4 + 4) hit points
- **Potion of superior healing:**  Restores 28 (8d4 + 8) hit points
- **Potion of water breathing:** For 1 hour, the drinker can breathe underwater
### Actions
- **Multiattack:** The alchemist attacks twice with their dagger.
- **Dagger:** Melee or Ranged Weapon Attack: +6 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 5 (1d4 + 3) piercing damage plus 10 (3d6) poison damage.
- **Bomb (3/Day):** The alchemist lobs a bomb at a point they can see within 80 feet. Upon impact  the bomb explodes in a 10-foot radius. Creatures in the area make a DC 15 Dexterity saving throw  taking 24 (7d6) fire damage on a failure or half damage on a success.
### Bonus Actions
- **Alter Bomb:** The alchemist quickly swaps reagents to change the damage dealt by their next bomb to acid, cold, lightning, poison, or thunder.
- **Potion:** The alchemist drinks or administers a potion.
### Reactions
- **Desperate Drink (1/Day:** When the alchemist is dealt damage, they drink a potion.
- **Alchemists brew concoctions with potent magical and chemical properties:** Some alchemists perform dangerous experiments to perfect new alchemical recipes, while others fabricate guardians and other constructs in pursuit of the creation of life itself.
}}
```