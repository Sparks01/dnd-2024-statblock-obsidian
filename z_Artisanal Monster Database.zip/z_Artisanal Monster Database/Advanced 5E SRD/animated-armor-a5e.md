```monsterwide
{{monster,frame,wide
## Animated Armor
*Medium Construct*
{{stats
{{vitals
**AC**         :: 18
**HP**         :: 31 (7d8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison, psychic
**Senses**      :: blindsight 60 ft. (blind beyond this radius), passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 1 (PB +2)
}}
### Traits
- **Spell-created:** The DC for dispel magic to destroy this creature is 19.
- **False Appearance:** While motionless, the armor is indistinguishable from normal armor.
### Actions
- **Weapon:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 7 (1d10 + 2) bludgeoning  piercing  or slashing damage  depending on weapon.
}}
```