```monsterwide
{{monster,frame,wide
## Ankheg Spawn
*Medium Monstrosity*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 11 (2d8+2)
**Speed**      :: 30 ft. burrow 10 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Resistances:** acid
**Senses**      :: tremorsense 30 ft., passive Perception 12
**Languages**   :: ### Actions
**CR**          :: 1/4 (PB +2)
}}
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6 + 2) slashing damage.
- **Claws:** Melee Weapon Attack: +4 to hit, reach 5 ft., one Medium or smaller creature. Hit: 4 (1d4 + 2) slashing damage  and the target makes a DC 12 Strength check. On a failure  it is knocked prone. If the target is already prone  the ankheg can instead move up to half its Speed  dragging the target with it.
- **Acid Spit:** Ranged Weapon Attack: +3 to hit, range 30 ft., one creature. Hit: 4 (1d8) acid damage.
}}
```