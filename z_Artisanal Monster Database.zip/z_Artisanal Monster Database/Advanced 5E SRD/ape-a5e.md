```monsterwide
{{monster,frame,wide
## Ape
*Medium Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 19 (3d8+6)
**Speed**      :: 30 ft. climb 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +5, perception +3
**Senses**      :: passive Perception 13
**Languages**   :: ### Actions
**CR**          :: 1/2 (PB +2)
}}
### Actions
- **Multiattack:** The ape attacks twice with its fists.
- **Fists:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 5 (1d4+3) bludgeoning damage.
- **Rock:** Ranged Weapon Attack: +5 to hit, range 25/50 ft., one target. Hit: 6 (1d6+3) bludgeoning damage.
}}
```