```monsterwide
{{monster,frame,wide
## Apprentice Mage
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 11 (2d8+2)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: arcana +4, history +4
**Senses**      :: passive Perception 10
**Languages**   :: any one
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Spellcasting:** The apprentice mage is a 2nd level spellcaster. Their spellcasting ability is Intelligence (spell save DC 12
 +4 to hit with spell attacks). They have the following wizard spells prepared:
 Cantrips (at will): fire bolt
 light
 prestidigitation
 1st-level (3 slots): detect magic
 magic missile
 shield
### Actions
- **Dagger:** Melee or Ranged Weapon Attack: +2 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 2 (1d4) piercing damage.
- **Fire Bolt (Cantrip; V, S):** Ranged Spell Attack: +4 to hit, range 120 ft., one target. Hit: 5 (1d10) fire damage.
- **Magic Missile (1st-Level; V, S):** Three glowing arrows fly from the mage simultaneously  unerringly hitting up to 3 creatures within 120 feet. Each arrow deals 3 (1d4 + 1) force damage.
### Reactions
- **Shield (1st-Level; V:** When the mage is hit by an attack or targeted by magic missile, they gain a +5 bonus to AC (including against the triggering attack) and immunity to magic missile. These benefits last until the start of their next turn.
- **Whether a student attending a wizard college or serving a crotchety master:** Apprentice mage statistics can also be used to represent an older hedge wizard of limited accomplishments.
}}
```