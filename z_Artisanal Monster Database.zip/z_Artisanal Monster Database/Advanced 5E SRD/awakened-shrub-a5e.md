```monsterwide
{{monster,frame,wide
## Awakened Shrub
*Small Plant*
{{stats
{{vitals
**AC**         :: 9
**HP**         :: 7 (2d6)
**Speed**      :: 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** fire
**Senses**      :: passive Perception 10
**Languages**   :: one language known by its creator
**CR**          :: 0 (PB +2)
}}
### Traits
- **False Appearance:** While motionless, the shrub is indistinguishable from a normal shrub.
### Actions
- **Rake:** Melee Weapon Attack: +1 to hit, reach 5 ft., one target. Hit: 1 slashing damage.
}}
```