```monsterwide
{{monster,frame,wide
## Awakened Tree
*Huge Plant*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 51 (6d12+12)
**Speed**      :: 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** fire
**Senses**      :: passive Perception 10
**Languages**   :: one language known by its creator
**CR**          :: 2 (PB +2)
}}
### Traits
- **False Appearance:** While motionless, the tree is indistinguishable from a normal tree.
### Actions
- **Slam:** Melee Weapon Attack: +6 to hit, reach 10 ft., one target. Hit: 14 (3d6+4) bludgeoning damage.
}}
```