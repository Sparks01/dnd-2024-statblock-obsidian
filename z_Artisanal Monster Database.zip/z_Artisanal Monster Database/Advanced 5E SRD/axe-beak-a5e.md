```monsterwide
{{monster,frame,wide
## Axe Beak
*Large Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 16 (3d10)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 10
**Senses**      :: passive Perception 10
**Languages**   :: ### Actions
**CR**          :: 1/4 (PB +2)
}}
### Actions
- **Beak:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6+2) slashing damage.
}}
```