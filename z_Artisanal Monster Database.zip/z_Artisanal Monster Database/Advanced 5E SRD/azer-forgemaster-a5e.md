```monsterwide
{{monster,frame,wide
## Azer Forgemaster
*Medium elemental*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 78 (12d8+24)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** cold
**Senses**      :: passive Perception 13
**Languages**   :: Common, Ignan
**CR**          :: 4 (PB +2)
}}
### Traits
- **Fiery Aura:** A creature that ends its turn within 5 feet of one or more azers takes 5 (1d10) fire damage. The azer sheds bright light in a 10-foot radius and dim light for an additional 10 feet.
### Actions
- **Multiattack:** The azer attacks with its returning hammer and uses Bonfire if available.
- **Returning Hammer:** Melee or Ranged Weapon Attack: +6 to hit, reach 5 ft. or range 20/60 feet  one target. Hit: 8 (1d8 + 4) bludgeoning damage plus 7 (2d6) fire damage. The azers hammer returns to its hand after its thrown.
- **Bonfire (3/Day):** A 5-foot-square space within 60 feet catches fire. A creature takes 10 (3d6) fire damage when it enters this area for the first time on a turn or starts its turn there. A creature can use an action to extinguish this fire.
### Bonus Actions
- **Fire Step:** While standing in fire, the azer can magically teleport up to 90 feet to a space within fire.
}}
```