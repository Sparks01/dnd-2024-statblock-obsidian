```monsterwide
{{monster,frame,wide
## Baboon
*Small Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 3 (1d6)
**Speed**      :: 30 ft. climb 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 11
**Senses**      :: passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Pack Tactics:** The baboon has advantage on attack rolls against a creature if at least one of the baboons allies is within 5 feet of the creature and not incapacitated.
### Actions
- **Bite:** Melee Weapon Attack: +1 to hit, reach 5 ft., one target. Hit: 1 piercing damage.
}}
```