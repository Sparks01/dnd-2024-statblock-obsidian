```monsterwide
{{monster,frame,wide
## Badger
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 3 (1d4+1)
**Speed**      :: 20 ft. burrow 5 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 30 ft., passive Perception 11
**Senses**      :: darkvision 30 ft., passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Keen Smell:** The badger has advantage on Perception checks that rely on smell.
### Actions
- **Bite:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 1 piercing damage. If this damage would reduce a Small or larger target to 0 hit points  the target takes no damage from this attack.
}}
```