```monsterwide
{{monster,frame,wide
## Bandit
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 9 (2d8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 10
**Senses**      :: passive Perception 10
**Languages**   :: any one
**CR**          :: 1/8 (PB +2)
}}
### Actions
- **Scimitar:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 4 (1d6 + 1) slashing damage.
- **Light Crossbow:** Ranged Weapon Attack: +2 to hit, range 80/320 ft., one target. Hit: 4 (1d8) piercing damage.
- **Bandits are outlaws who live by violence:** Most are highway robbers  though a few are principled exiles or freedom fighters.
}}
```