```monsterwide
{{monster,frame,wide
## Banshee
*Medium Undead*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 58 (13d8)
**Speed**      :: 30 ft. fly 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** cold, necrotic, poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: the languages it spoke in life
**CR**          :: 4 (PB +2)
}}
### Traits
- **Death Howl:** When reduced to 0 hit points, the banshee uses Baleful Wail.
- **Detect Life:** The banshee magically senses the general direction of living creatures up to 5 miles away.
- **Incorporeal Movement:** The banshee can move through creatures and objects. It takes 5 (1d10) force damage if it ends its turn inside an object.
- **Undead Nature:** A banshee doesnt require air, sustenance, or sleep.
- **Unquiet Spirit:** If defeated in combat, the banshee returns on the anniversary of its death. It can be permanently put to rest only by finding and casting remove curse on its grave or by righting whatever wrong was done to it.
### Actions
- **Presage Death:** The banshee targets a creature within 60 feet that can hear it  predicting its doom. The target makes a DC 14 Wisdom saving throw. On a failure  the target takes 11 (2d6 + 4) psychic damage and is magically cursed for 1 hour. While cursed in this way  the target has disadvantage on saving throws against the banshees Baleful Wail.
- **Baleful Wail:** The banshee shrieks. All living creatures within 30 feet of it that can hear it make a DC 14 Constitution saving throw. On a failure  a creature takes 11 (2d6 + 4) psychic damage. If the creature is cursed by the banshee  it drops to 0 hit points instead.
### Reactions
- **Wounded Warning:** When the banshee takes damage from a creature within 60 feet, it uses Presage Death on the attacker.
}}
```