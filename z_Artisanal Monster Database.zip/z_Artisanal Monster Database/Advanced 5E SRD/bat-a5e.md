```monsterwide
{{monster,frame,wide
## Bat
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 1 (1d4-1)
**Speed**      :: 5 ft. fly 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 60 ft., passive Perception 11
**Senses**      :: blindsight 60 ft., passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Echolocation:** The bat can't use blindsight while deafened.
- **Keen Hearing:** The bat has advantage on Perception checks that rely on hearing.
### Actions
- **Bite:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 1 piercing damage. If this damage would reduce a Small or larger target to 0 hit points  the target takes no damage from this attack.
}}
```