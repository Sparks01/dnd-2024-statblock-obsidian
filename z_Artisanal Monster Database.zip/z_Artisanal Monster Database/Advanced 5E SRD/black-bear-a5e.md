```monsterwide
{{monster,frame,wide
## Black Bear
*Medium Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 19 (3d8+6)
**Speed**      :: 40 ft. climb 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Keen Smell:** The bear has advantage on Perception checks that rely on smell.
### Actions
- **Multiattack:** The bear attacks once with its bite and once with its claws.
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6+2) piercing damage.
- **Claws:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6+2) slashing damage.
}}
```