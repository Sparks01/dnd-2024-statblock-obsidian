```monsterwide
{{monster,frame,wide
## Black Dragon Wyrmling
*Medium Dragon*
{{stats
{{vitals
**AC**         :: 17
**HP**         :: 44 (8d8+6)
**Speed**      :: 30 ft. fly 60 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2, stealth +5
**Senses**      :: blindsight 10 ft., darkvision 60 ft., passive Perception 12
**Languages**   :: Draconic
**CR**          :: 2 (PB +2)
}}
### Traits
- **Ambusher:** When submerged in water, the dragon has advantage on Stealth checks.
- **Amphibious:** The dragon can breathe air and water.
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 13 (2d10 + 2) piercing damage.
- **Acid Breath (Recharge 5-6):** The dragon exhales sizzling acid in a 20-foot-long  5-foot-wide line. Each creature in that area makes a DC 11 Dexterity saving throw  taking 13 (3d8) acid damage on a failed save or half damage on a success.
}}
```