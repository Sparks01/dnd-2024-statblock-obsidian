```monsterwide
{{monster,frame,wide
## Blink Dog
*Medium fey*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 22 (4d8+4)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +5
**Senses**      :: passive Perception 13
**Languages**   :: Blink Dog, understands but cant speak Sylvan
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Keen Hearing and Smell:** The blink dog has advantage on Perception checks that rely on hearing and smell.
### Actions
- **Bite:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 5 (1d6+2) piercing damage.
### Bonus Actions
- **Teleport (Recharge 4-6):** The blink dog magically teleports up to 40 feet to an unoccupied space it can see.
}}
```