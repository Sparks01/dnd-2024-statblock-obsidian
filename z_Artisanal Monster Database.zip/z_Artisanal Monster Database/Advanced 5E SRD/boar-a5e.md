```monsterwide
{{monster,frame,wide
## Boar
*Medium Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 11 (2d8+2)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 10
**Senses**      :: passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Relentless (1/Day):** If the boar takes 5 or less damage that would reduce it to 0 hit points, it is instead reduced to 1 hit point.
### Actions
- **Tusk:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 4 (1d6+1) slashing damage. If the boar moves at least 20 feet straight towards the target before the attack  the attack deals an extra 3 (1d6) slashing damage and the target makes a DC 11 Strength saving throw  falling prone on a failure.
}}
```