```monsterwide
{{monster,frame,wide
## Boggard Bravo
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 27 (6d8)
**Speed**      :: 20 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +4, survival +2
**Senses**      :: passive Perception 10
**Languages**   :: Boggard
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Amphibious:** The boggard can breathe air and water.
- **Speak with Frogs and Toads:** The boggard can communicate with frogs and toads.
### Actions
- **Vaulting Leap:** The boggard jumps up to its Speed horizontally and half its Speed vertically without provoking opportunity attacks. If its within 5 feet of a creature at the end of this movement  it may make a melee spear attack against that creature with advantage.
- **Spear:** Melee or Ranged Weapon Attack: +3 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 4 (1d6 + 1) piercing damage.
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 4 (1d4 + 2) piercing damage.
### Bonus Actions
- **Tongue:** Melee Weapon Attack: +3 to hit, reach 15 ft., one creature. Hit: The target must make a DC 11 Strength saving throw. On a failure, the boggard pulls the target up to 10 feet, or knocks the target prone, or forces the target to drop one item it is holding (boggards choice).
}}
```