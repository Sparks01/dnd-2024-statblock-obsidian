```monsterwide
{{monster,frame,wide
## Bolt-Thrower
*Small Construct*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 44 (8d6+16)
**Speed**      :: 15 ft. climb 15 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +0
**Senses**      :: blindsight 120 ft. (blind beyond that range), passive Perception 14
**Languages**   :: ### Special Abilities
**CR**          :: 2 (PB +2)
}}
### Traits
- **Clockwork Sights:** The bolt-thrower does not have disadvantage on attack rolls when making ranged attacks within 5 feet of a hostile creature.
- **Rooted:** The bolt-thrower can use a bonus action to anchor itself to or detach itself from a surface. While anchored, the bolt-throwers Speed is 0, and a DC 20 Strength check is required to detach it. A bolt-thrower cannot use its heavy crossbow unless it is anchored.
### Actions
- **Multiattack:** The bolt-thrower attacks once with each of its crossbows.
- **Light Crossbow:** Ranged Weapon Attack: +5 to hit, range 80/320 ft., one target. Hit: 7 (1d8 + 3) piercing damage.
- **Heavy Crossbow:** Ranged Weapon Attack: +5 to hit, range 100/400 ft., one target. Hit: 8 (1d10 + 3) piercing damage.
}}
```