```monsterwide
{{monster,frame,wide
## Brown Bear
*Large Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 34 (4d10+12)
**Speed**      :: 30 ft. climb 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 1 (PB +2)
}}
### Traits
- **Keen Smell:** The bear has advantage on Perception checks that rely on smell.
### Actions
- **Bite:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 11 (2d6+4) piercing damage.
- **Claws:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 9 (2d4+4) slashing damage. If the target is a Medium or smaller creature  it is grappled (escape DC 14). Until this grapple ends  the bear can't attack a different target with its claws.
}}
```