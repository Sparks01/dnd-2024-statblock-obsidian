```monsterwide
{{monster,frame,wide
## Bugbear
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 30 (5d8+8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +4, stealth +4, perception +3, survival +3
**Senses**      :: darkvision 60 ft., passive Perception 15
**Languages**   :: Common, Goblin
**CR**          :: 1 (PB +2)
}}
### Actions
- **Strangle:** Melee Weapon Attack: +4 to hit, reach 10 ft., one Medium or smaller creature that is surprised  grappled by the bugbear  or that can't see the bugbear. Hit: 9 (2d6 + 2) bludgeoning damage  and the target is pulled 5 feet towards the bugbear and grappled (escape DC 12). Until this grapple ends  the bugbear automatically hits with the Strangle attack and the target can't breathe.
- **Maul:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 9 (2d6 + 2) bludgeoning damage.
- **Javelin:** Melee or Ranged Weapon Attack: +4 to hit, reach 5 ft. or range 30/120 ft., one target. Hit: 5 (1d6 + 2) piercing damage  or 12 (3d6 + 2) piercing damage if the target is a creature that is surprised or that can't see the bugbear.
- **Stealthy Sneak:** The bugbear moves up to half its Speed without provoking opportunity attacks. It can then attempt to hide.
}}
```