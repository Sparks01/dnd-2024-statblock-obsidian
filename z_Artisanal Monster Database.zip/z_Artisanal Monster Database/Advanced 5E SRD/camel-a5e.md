```monsterwide
{{monster,frame,wide
## Camel
*Medium Beast*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 15 (2d10+4)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 9
**Senses**      :: passive Perception 9
**Languages**   :: ### Actions
**CR**          :: 1/8 (PB +2)
}}
### Actions
- **Bite:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 2 (1d4) bludgeoning damage.
}}
```