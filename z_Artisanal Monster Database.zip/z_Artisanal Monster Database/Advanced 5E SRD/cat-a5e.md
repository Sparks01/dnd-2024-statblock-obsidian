```monsterwide
{{monster,frame,wide
## Cat
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 2 (1d4)
**Speed**      :: 40 ft. climb 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +4
**Senses**      :: darkvision 30 ft., passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Keen Smell:** The cat has advantage on Perception checks that rely on smell.
- **Safe Landing:** The cat takes no falling damage from the first 10 feet that it falls.
### Actions
- **Claws:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 1 slashing damage. If this damage would reduce a Small or larger target to 0 hit points  the target takes no damage from this attack.
}}
```