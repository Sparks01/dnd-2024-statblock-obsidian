```monsterwide
{{monster,frame,wide
## Cave Ogre
*Large Giant*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 119 (14d10+42)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 60 ft., passive Perception 10
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Common, Giant
**CR**          :: 2 (PB +2)
}}
### Traits
- **Elite Recovery:** At the end of each of its turns while bloodied, the ogre can end one condition or effect on itself. It can do this even when unconscious or incapacitated.
### Actions
- **Greatclub:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 13 (2d8 + 4) bludgeoning damage  and if the target is a Medium or smaller creature  it makes a DC 14 Strength saving throw  falling prone on a failure.
- **Sweeping Strike:** Melee Weapon Attack: +6 to hit, reach 5 ft.  all creatures within 5 feet. Hit: 8 (1d8 + 4) bludgeoning damage  and if the target is a Medium or smaller creature  it makes a DC 14 Strength saving throw. On a failure  it is pushed 10 feet away from the ogre.
- **Javelin:** Melee or Ranged Weapon Attack: +6 to hit, reach 5 ft. or range 30/120 ft., one target. Hit: 11 (2d6 + 4) piercing damage.
}}
```