```monsterwide
{{monster,frame,wide
## Centaur
*Large fey*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 45 (6d10+12)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: nature +5, perception +5, survival +5
**Senses**      :: passive Perception 17
**Languages**   :: Common, Elvish, Sylvan
**CR**          :: 2 (PB +2)
}}
### Actions
- **Multiattack:** The centaur attacks with its pike and its hooves.
- **Pike:** Melee Weapon Attack: +5 to hit, reach 10 ft., one target. Hit: 8 (1d10 + 3) piercing damage.
- **Hooves:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 8 (2d4 + 3) bludgeoning damage. If this attack deals damage  the centaurs movement doesnt provoke opportunity attacks from the target for the rest of the centaurs turn.
- **Shortbow:** Ranged Weapon Attack: +5 to hit, range 80/320 ft., one target. Hit: 10 (2d6 + 3) piercing damage.
- **Deadeye Shot (1/Day):** The centaur makes a shortbow attack with advantage.
}}
```