```monsterwide
{{monster,frame,wide
## Champion Warrior
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 90 (12d8+36)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +7, intimidation +5, perception +4, stealth +7, survival +4
**Senses**      :: passive Perception 14
**Languages**   :: any one
**CR**          :: 5 (PB +2)
}}
### Actions
- **Multiattack:** The warrior attacks twice.
- **Greataxe:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 10 (1d12 + 4) slashing damage. If the warrior has moved this turn, this attack is made with advantage.
}}
```