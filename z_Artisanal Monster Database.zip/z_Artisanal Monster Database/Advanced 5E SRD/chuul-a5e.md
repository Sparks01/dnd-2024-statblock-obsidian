```monsterwide
{{monster,frame,wide
## Chuul
*Large aberration*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 93 (11d10+33)
**Speed**      :: 30 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison
**Senses**      :: darkvision 60 ft., passive Perception 13
**Languages**   :: understands Deep Speech but can't speak
**CR**          :: 5 (PB +2)
}}
### Traits
- **Amphibious:** The chuul can breathe air and water.
- **Detect Magic:** The chuul senses a magical aura around any visible creature or object within 120 feet that bears magic.
### Actions
- **Multiattack:** If the chuul is grappling a creature  it uses its tentacle on that creature. It then makes two pincer attacks.
- **Pincer:** Melee Weapon Attack: +7 to hit, reach 5 ft., one Large or smaller target. Hit: 11 (2d6 + 4) bludgeoning damage. If the target is a creature  it is grappled (escape DC 15). When carrying a grappled creature  the chuul can move at full speed. A pincer that is being used to grapple a creature can be used only to attack that creature.
- **Tentacle:** A grappled creature makes a DC 14 Constitution saving throw. On a failure  it is paralyzed for 1 minute. The creature repeats the saving throw at the end of each of its turns  ending the paralysis on a success.
}}
```