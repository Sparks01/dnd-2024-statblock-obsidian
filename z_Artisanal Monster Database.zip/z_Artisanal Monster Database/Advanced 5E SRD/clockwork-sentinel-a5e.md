```monsterwide
{{monster,frame,wide
## Clockwork Sentinel
*Medium Construct*
{{stats
{{vitals
**AC**         :: 18
**HP**         :: 60 (8d8+24)
**Speed**      :: 35 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +5, perception +0, survival +0
**Senses**      :: blindsight 120 ft. (blind beyond that range), passive Perception 12
**Languages**   :: ### Special Abilities
**CR**          :: 4 (PB +2)
}}
### Traits
- **False Appearance:** While motionless, the sentinel is indistinguishable from normal armor.
- **Clockwork Nature:** A clockwork doesnt require air, nourishment, or rest, and is immune to disease.
- **Immutable Form:** The clockwork is immune to any effect that would alter its form.
### Actions
- **Multiattack:** The sentinel attacks three times.
- **Halberd:** Melee Weapon Attack: +5 to hit, reach 10 ft., one target. Hit: 8 (1d10 + 3) slashing damage.
- **Calculated Sweep:** The sentinel makes a melee attack against each creature of its choice within 10 feet. On a critical hit  the target makes a DC 13 Strength saving throw  falling prone on a failure.
### Bonus Actions
- **Overclock (Recharge 5-6):** The sentinel takes the Dash action.
### Reactions
- **Parry:** The sentinel adds 2 to its AC against one melee attack that would hit it.
}}
```