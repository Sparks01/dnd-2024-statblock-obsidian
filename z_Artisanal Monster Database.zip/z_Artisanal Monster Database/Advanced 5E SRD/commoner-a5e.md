```monsterwide
{{monster,frame,wide
## Commoner
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 4 (1d8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: any +0
**Senses**      :: passive Perception 10 (14 if proficient)
**Languages**   :: any one
**CR**          :: 0 (PB +2)
}}
### Actions
- **Club:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 2 (1d4) bludgeoning damage.
- **Stone:** Ranged Weapon Attack: +2 to hit, range 10/30 ft., one target. Hit: 2 (1d4) bludgeoning damage.
}}
```