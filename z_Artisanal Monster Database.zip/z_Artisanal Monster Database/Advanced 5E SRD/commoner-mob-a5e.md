```monsterwide
{{monster,frame,wide
## Commoner Mob
*Huge humanoid*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 45 (10d8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 10
**Senses**      :: passive Perception 10
**Languages**   :: any one
**CR**          :: 0 (PB +2)
}}
### Traits
- **Area Vulnerability:** The mob takes double damage from any effect that targets an area.
- **Mob Dispersal:** When the mob is reduced to 0 hit points, it turns into 5 (1d6 + 2) commoners with 2 hit points.
- **Mob:** The mob is composed of 10 or more commoners. If it is subjected to a spell, attack, or other effect that affects only one target, it takes any damage but ignores other effects. It can share its space with Medium or smaller creatures or objects. The mob can move through any opening large enough for one Medium creature.
### Actions
- **Clubs:** Melee Weapon Attack: +2 to hit, reach 5 ft., up to two targets. Hit: 10 (4d4) bludgeoning damage  or half damage if the mob is bloodied.
- **Stones:** Ranged Weapon Attack: +2 to hit, range 10/30 ft., up to two targets. Hit: 10 (4d4) bludgeoning damage or half damage if the mob is bloodied.
}}
```