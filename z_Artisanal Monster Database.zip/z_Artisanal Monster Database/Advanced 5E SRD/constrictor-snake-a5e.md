```monsterwide
{{monster,frame,wide
## Constrictor Snake
*Large Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 13 (2d10+2)
**Speed**      :: 30 ft. climb 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 10 ft., passive Perception 10
**Senses**      :: blindsight 10 ft., passive Perception 10
**Languages**   :: ### Actions
**CR**          :: 1/4 (PB +2)
}}
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 6 (1d8+2) piercing damage.
- **Constrict:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6+2) bludgeoning damage and the target is grappled (escape DC 14). Until this grapple ends  the target is restrained and the snake can't constrict a different target.
}}
```