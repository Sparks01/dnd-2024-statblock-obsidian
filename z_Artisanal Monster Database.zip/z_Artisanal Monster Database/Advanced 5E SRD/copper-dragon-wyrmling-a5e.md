```monsterwide
{{monster,frame,wide
## Copper Dragon Wyrmling
*Medium Dragon*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 44 (8d8+8)
**Speed**      :: 30 ft. climb 30 ft. fly 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2, stealth +3
**Senses**      :: blindsight 10 ft., darkvision 60 ft., passive Perception 17
**Languages**   :: Draconic
**CR**          :: 2 (PB +2)
}}
### Traits
- **Flow Within the Mountain:** The dragon has advantage on Stealth checks made to hide in mountainous regions.
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 13 (2d10 + 2) piercing damage.
- **Breath Weapons (Recharge 5-6):** The dragon uses one of the following breath weapons:
- **Acid Breath:** The dragon exhales acid in a 20-foot-long  5-foot wide-line. Each creature in the area makes a DC 11 Dexterity saving throw  taking 13 (3d8) acid damage on a failed save or half damage on a success.
- **Slowing Breath:** The dragon exhales toxic gas in a 15-foot cone. Each creature in the area makes a DC 11 Constitution saving throw  becoming slowed for 1 minute on a failure. A creature repeats the saving throw at the end of each of its turns  ending the effect on itself on a success.
}}
```