```monsterwide
{{monster,frame,wide
## Crab
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 2 (1d4)
**Speed**      :: 20 ft. swim 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 30 ft., passive Perception 9
**Senses**      :: blindsight 30 ft., passive Perception 9
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Amphibious:** The crab can breathe air and water.
### Actions
- **Claws:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 1 bludgeoning damage. If this damage would reduce a Small or larger target to 0 hit points  the target takes no damage from this attack.
}}
```