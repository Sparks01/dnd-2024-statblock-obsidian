```monsterwide
{{monster,frame,wide
## Crime Boss
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 127 (15d8+60)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: deception +6, insight +6, intimidation +6, perception +6, persuasion +6, stealth +5
**Senses**      :: passive Perception 16
**Languages**   :: any two
**CR**          :: 6 (PB +2)
}}
### Actions
- **Multiattack:** The boss attacks three times with their shortsword.
- **Shortsword:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 7 (1d6 + 4) piercing damage.
- **Dagger:** Melee or Ranged Weapon Attack: +7 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 6 (1d4 + 4) piercing damage.
- **Mark for Death:** The boss targets a creature within 30 feet that can see or hear them. For 1 minute or until the boss threatens a different target  the target takes an extra 7 (2d6) damage whenever the boss hits it with a weapon attack.
### Reactions
- **Command Bodyguard:** When the boss would be hit by an attack, they command an ally within 5 feet to use its reaction to switch places with the boss. The ally is hit by the attack instead of the boss.
- **Offhand Dagger:** When missed by an attack, the boss makes a dagger attack.
}}
```