```monsterwide
{{monster,frame,wide
## Crocodile
*Large Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 19 (3d10+3)
**Speed**      :: 20 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +2
**Senses**      :: passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Hold Breath:** The crocodile can hold its breath for 15 minutes.
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 7 (1d10+2) piercing damage and the target is grappled (escape DC 12). Until this grapple ends  the target is restrained and the crocodile can't bite a different target.
}}
```