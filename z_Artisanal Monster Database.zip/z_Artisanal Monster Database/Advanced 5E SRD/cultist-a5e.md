```monsterwide
{{monster,frame,wide
## Cultist
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 9 (2d8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: deception +2, religion +2
**Senses**      :: passive Perception 10
**Languages**   :: any one
**CR**          :: 1/8 (PB +2)
}}
### Traits
- **Fanatic:** The cultist has advantage on saving throws against being charmed or frightened by creatures not in their cult.
### Actions
- **Dagger:** Melee or Ranged Weapon Attack: +4 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 4 (1d4 + 2) piercing damage.
- **Cultists worship forbidden gods, devils, demons, and other sinister beings:** Many cultists work to summon the object of their devotion to the world so it might grant them power and destroy their enemies.
}}
```