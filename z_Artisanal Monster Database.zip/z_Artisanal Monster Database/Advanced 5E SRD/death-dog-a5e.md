```monsterwide
{{monster,frame,wide
## Death Dog
*Medium Monstrosity*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 32 (5d8+10)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +4
**Senses**      :: darkvision 120 ft., passive Perception 18
**Languages**   :: ### Special Abilities
**CR**          :: 1 (PB +2)
}}
### Traits
- **Two Heads:** The death dog has advantage on Perception checks and on saving throws made to resist being blinded, charmed, deafened, frightened, stunned, or knocked unconscious, and it can't be flanked.
### Actions
- **Multiattack:** The death dog attacks twice with its bite.
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6+2) piercing damage. If the target is a creature  it makes a DC 12 Constitution saving throw. On a failure  it becomes infected with a disease. Until this disease is cured  the target is poisoned. While diseased  the target makes a DC 12 Constitution saving throw every 24 hours  reducing its hit point maximum by 5 (1d10) on a failure and ending the disease on a success. This hit point maximum reduction lasts until the disease is cured. The target dies if its hit point maximum is reduced to 0.
}}
```