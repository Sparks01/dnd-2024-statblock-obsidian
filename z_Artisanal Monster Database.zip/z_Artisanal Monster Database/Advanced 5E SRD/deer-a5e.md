```monsterwide
{{monster,frame,wide
## Deer
*Medium Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 4 (1d8)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 12
**Senses**      :: passive Perception 12
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Keen Smell:** The deer has advantage on Perception checks that rely on smell.
### Actions
- **Bite:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 1 piercing damage.
- **Headbutt:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 2 (1d4) piercing damage.
}}
```