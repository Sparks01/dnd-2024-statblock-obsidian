```monsterwide
{{monster,frame,wide
## Diplodocus
*Gargantuan Beast*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 139 (9d20+45)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 11
**Senses**      :: passive Perception 11
**Languages**   :: ### Actions
**CR**          :: 7 (PB +2)
}}
### Actions
- **Multiattack:** The diplodocus makes a stomp attack and a tail attack against two different targets.
- **Stomp:** Melee Weapon Attack: +10 to hit, reach 5 ft., one target. Hit: 21 (4d6 + 7) bludgeoning damage.
- **Tail:** Melee Weapon Attack: +10 to hit, reach 15 ft., one target. Hit: 17 (3d6 + 7) bludgeoning damage. If the target is a Large or smaller creature  it is pushed 10 feet away from the diplodocus and knocked prone.
}}
```