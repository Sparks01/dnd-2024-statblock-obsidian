```monsterwide
{{monster,frame,wide
## Dire Tyrannosaurus Rex
*Huge Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 253 (22d12+110)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 11
**Senses**      :: passive Perception 11
**Languages**   :: ### Actions
**CR**          :: 8 (PB +2)
}}
### Actions
- **Multiattack:** The tyrannosaurus makes a bite attack and a tail attack against two different targets.
- **Bite:** Melee Weapon Attack: +9 to hit, reach 10 ft., one target. Hit: 25 (3d12 + 6) piercing damage. If the target is a creature  it is grappled (escape DC 17). Until this grapple ends  the tyrannosaurus can't bite a different creature and it has advantage on bite attacks against the grappled creature.
- **Tail:** Melee Weapon Attack: +9 to hit, reach 10 ft., one target. Hit: 19 (3d8 + 6) bludgeoning damage.
}}
```