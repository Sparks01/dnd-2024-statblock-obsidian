```monsterwide
{{monster,frame,wide
## Dire Wolf
*Large Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 30 (4d10+8)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +4
**Senses**      :: darkvision 30 ft., passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 1 (PB +2)
}}
### Traits
- **Keen Hearing and Smell:** The wolf has advantage on Perception checks that rely on hearing and smell.
- **Pack Tactics:** The wolf has advantage on attack rolls against a creature if at least one of the wolfs allies is within 5 feet of the creature and not incapacitated.
### Actions
- **Bite:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 8 (2d4+3) piercing damage. If the target is a creature  it makes a DC 13 Strength saving throw  falling prone on a failure.
}}
```