```monsterwide
{{monster,frame,wide
## Doppelganger
*Medium Monstrosity*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 52 (8d8+16)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: deception +5, insight +4, stealth +6
**Senses**      :: darkvision 60 ft., passive Perception 12
**Languages**   :: Common
**CR**          :: 3 (PB +2)
}}
### Actions
- **Precise Strike:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 11 (2d6 + 4) bludgeoning damage. If the target is surprised  it takes an extra 10 (3d6) damage.
### Bonus Actions
- **Shapeshift:** The doppelganger changes its form to that of any Small or Medium humanoid creature it has seen before, or back into its true form. While shapeshifted, its statistics are the same. Any equipment is not transformed. It reverts to its true form if it dies.
- **Read Thoughts:** The doppelganger magically reads the surface thoughts of one creature within 60 feet that it can see. Until the end of its turn, it has advantage on attack rolls and on Deception, Insight, Intimidation, and Persuasion checks against the creature.
}}
```