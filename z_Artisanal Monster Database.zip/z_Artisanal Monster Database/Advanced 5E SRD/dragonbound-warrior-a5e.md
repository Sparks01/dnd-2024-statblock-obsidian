```monsterwide
{{monster,frame,wide
## Dragonbound Warrior
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 11 (2d8+2)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +3, stealth +3, perception +4, survival +4
**Senses**      :: passive Perception 14
**Languages**   :: any one
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Draconic Resistance:** The warrior is resistant to one damage type dealt by their draconic masters breath weapon.
- **Draconic Smite:** The warriors weapon attacks deal an additional (1d6) damage of one damage type dealt by their draconic masters breath weapon.
### Actions
- **Spear:** Melee or Ranged Weapon Attack: +3 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 4 (1d6 + 1) piercing damage.
}}
```