```monsterwide
{{monster,frame,wide
## Drainpipe Gargoyle
*Medium elemental*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 45 (6d8+18)
**Speed**      :: 30 ft. fly 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +4
**Senses**      :: darkvision 60 ft., passive Perception 14
**Languages**   :: Terran
**CR**          :: 2 (PB +2)
}}
### Traits
- **False Appearance:** While motionless, the gargoyle is indistinguishable from a normal statue.
- **Elemental Nature:** Gargoyles dont require air, sustenance, or sleep.
### Actions
- **Multiattack:** The gargoyle attacks with its bite and its claws.
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6 + 2) piercing damage.
- **Claws:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6 + 2) slashing damage  or 9 (2d6 + 2) slashing damage if the gargoyle started its turn at least 20 feet above the target.
- **Rock:** Ranged Weapon Attack: +4 to hit, range 20/60 ft., one target. Hit: 9 (2d6 + 2) bludgeoning damage.
- **Spit (Recharge 5-6):** The gargoyle spits a steam of water 5 feet wide and 30 feet long. Each creature in the area makes a DC 12 Strength saving throw  taking 10 (3d6) bludgeoning damage and being pushed up to 15 feet from the gargoyle on a failure. On a success  a creature takes half damage.
}}
```