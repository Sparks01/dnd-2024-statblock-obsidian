```monsterwide
{{monster,frame,wide
## Dretch
*Small Fiend*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 18 (4d6+4)
**Speed**      :: 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison
**Senses**      :: darkvision 60 ft., passive Perception 9
**Languages**   :: Abyssal
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Chaotic Evil:** The dretch radiates a Chaotic and Evil aura.
- **Energy-Sucking Aura:** A non-demon creature that takes an action or bonus action while within 10 feet of a dretch can't take another action, bonus action, or reaction until the start of its next turn.
### Actions
- **Bite:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 4 (1d6 + 1) piercing damage.
}}
```