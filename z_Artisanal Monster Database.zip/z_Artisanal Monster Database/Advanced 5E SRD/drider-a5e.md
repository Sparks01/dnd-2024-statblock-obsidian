```monsterwide
{{monster,frame,wide
## Drider
*Large Monstrosity*
{{stats
{{vitals
**AC**         :: 17
**HP**         :: 114 (12d10+48)
**Speed**      :: 30 ft. climb 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +6, stealth +6, survival +6
**Senses**      :: darkvision 120 ft., passive Perception 16
**Languages**   :: Undercommon, one more
**CR**          :: 6 (PB +2)
}}
### Traits
- **Spider Climb:** The drider can use its climb speed even on difficult surfaces and upside down on ceilings.
- **Sunlight Sensitivity:** While in sunlight, the drider has disadvantage on attack rolls, as well as on Perception checks that rely on sight.
- **Web Walker:** The drider ignores movement restrictions imposed by webs.
### Actions
- **Multiattack:** The drider makes a claws attack and then either a bite or longsword attack. Alternatively  it makes two longbow attacks.
- **Claws:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 15 (2d10 + 4) piercing damage  and the target is grappled (escape DC 15). While grappling a target  the drider can't attack a different target with its claws.
- **Bite:** Melee Weapon Attack: +6 to hit, reach 5 ft., one grappled creature. Hit: 2 (1d4) piercing damage plus 13 (3d8) poison damage.
- **Longsword (wielded two-handed):** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 9 (1d10 + 4) slashing damage.
- **Longbow:** Melee Weapon Attack: +6 to hit, range 120/600 ft., one target. Hit: 7 (1d8 + 3) piercing damage plus 7 (2d6) poison damage.
}}
```