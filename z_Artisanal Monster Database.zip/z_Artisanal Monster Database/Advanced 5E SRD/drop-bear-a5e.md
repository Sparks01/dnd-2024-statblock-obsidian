```monsterwide
{{monster,frame,wide
## Drop Bear
*Large Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 42 (5d10+15)
**Speed**      :: 40 ft. climb 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 3 (PB +2)
}}
### Traits
- **Keen Smell:** The bear has advantage on Perception checks that rely on smell.
- **Stealthy:** The drop bear has advantage on Stealth checks in forested areas.
- **Drop:** The drop bear takes no damage from falling 40 feet or fewer and deals an extra 7 (2d6) damage when it hits with an attack after falling at least 20 feet. A creature that takes this extra damage is knocked prone.
### Actions
- **Multiattack:** The bear makes two melee attacks.
- **Bite:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 9 (1d8+5) piercing damage.
- **Claws:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 7 (1d4+5) slashing damage. If the target is a Medium or smaller creature  it is grappled (escape DC 15). Until this grapple ends  the bear can't attack a different target with its claws.
}}
```