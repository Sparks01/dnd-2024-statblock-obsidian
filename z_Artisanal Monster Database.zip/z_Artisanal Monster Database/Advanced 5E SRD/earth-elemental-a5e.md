```monsterwide
{{monster,frame,wide
## Earth Elemental
*Large elemental*
{{stats
{{vitals
**AC**         :: 17
**HP**         :: 114 (12d10+48)
**Speed**      :: 30 ft. burrow 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** thunder
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Terran
**CR**          :: 5 (PB +2)
}}
### Traits
- **Earth Glide:** The elemental can burrow through nonmagical, unworked earth and stone without disturbing it.
- **Siege Monster:** The elemental deals double damage to objects and structures.
- **Elemental Nature:** An elemental doesnt require air, sustenance, or sleep.
### Actions
- **Multiattack:** The elemental makes two slam attacks.
- **Slam:** Melee Weapon Attack: +7 to hit, reach 10 ft., one target. Hit: 13 (2d8 + 4) bludgeoning damage.
- **Earths Embrace:** Melee Weapon Attack: +7 to hit, reach 5 ft., one Large or smaller creature. Hit: 17 (2d12 + 4) bludgeoning damage  and the target is grappled (escape DC 15). Until this grapple ends  the elemental can't burrow or use Earths Embrace and its slam attacks are made with advantage against the grappled target.
- **Rock:** Ranged Weapon Attack: +7 to hit, range 30/90 ft., one target. Hit: 15 (2d10 + 4) bludgeoning damage.
}}
```