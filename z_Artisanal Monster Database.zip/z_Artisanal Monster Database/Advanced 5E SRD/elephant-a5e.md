```monsterwide
{{monster,frame,wide
## Elephant
*Huge Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 76 (8d12+24)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 10
**Senses**      :: passive Perception 10
**Languages**   :: ### Actions
**CR**          :: 4 (PB +2)
}}
### Actions
- **Gore:** Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 19 (3d8+6) piercing damage. If the elephant moves at least 20 feet straight towards the target before the attack  the target makes a DC 16 Strength saving throw  falling prone on a failure.
- **Stomp:** Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 22 (3d10+6) bludgeoning damage.
### Bonus Actions
- **Trample Underfoot:** The elephant makes a stomp attack against a prone creature.
}}
```