```monsterwide
{{monster,frame,wide
## Elk
*Large Beast*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 15 (2d10+4)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 10
**Senses**      :: passive Perception 10
**Languages**   :: ### Actions
**CR**          :: 1/4 (PB +2)
}}
### Actions
- **Ram:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6+2) bludgeoning damage. If the target is a creature and the elk moves at least 20 feet straight towards the target before the attack  the target makes a DC 12 Strength saving throw  falling prone on a failure.
### Bonus Actions
- **Hooves:** Melee Weapon Attack: +4 to hit, reach 5 ft., one prone creature. Hit: 7 (2d4+2) bludgeoning damage.
}}
```