```monsterwide
{{monster,frame,wide
## Emerald Dragon Wyrmling
*Medium Dragon*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 45 (7d8+14)
**Speed**      :: 30 ft. burrow 15 ft. fly 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: deception +4, history +4, perception +2, stealth +4
**Senses**      :: darkvision 120 ft., passive Perception 12
**Languages**   :: Deep Speech, Draconic, Undercommon, telepathy 120 ft.
**CR**          :: 2 (PB +2)
}}
### Traits
- **Far Thoughts:** The dragon is aware of any creature that uses a psionic ability or communicates telepathically within 100 miles of it. As an action, the dragon can psionically observe a creature, object, or location it is familiar with within 100 miles. While observing a subject in this way, the dragon can see, hear, and communicate telepathically, but it is blind and deaf in regard to its physical senses and does not require food or water. The dragon can psionically observe a subject indefinitely and can end this effect and return to its own senses as an action.
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 13 (2d10 + 2) piercing damage.
- **Maddening Breath (Recharge 5-6):** The dragon screams  stripping flesh from bone in a 15-foot cone. Each creature in that area makes a DC 11 Constitution saving throw  taking 16 (3d10) thunder damage on a failed save or half damage on a success.
}}
```