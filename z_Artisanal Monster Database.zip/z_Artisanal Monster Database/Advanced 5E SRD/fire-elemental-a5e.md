```monsterwide
{{monster,frame,wide
## Fire Elemental
*Large elemental*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 90 (12d10+24)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** fire, poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Ignan
**CR**          :: 5 (PB +2)
}}
### Traits
- **Fire Form:** The elemental can move through a space as narrow as 1 inch wide without squeezing.
- **Fiery Aura:** A creature that ends its turn within 5 feet of the fire elemental takes 5 (1d10) fire damage. A creature that touches the elemental or hits it with a melee attack while within 5 feet of it takes 5 (1d10) fire damage. The elemental sheds bright light in a 30-foot radius and dim light for an additional 30 feet.
- **Water Weakness:** The elemental takes 6 (1d12) cold damage if it enters a body of water or starts its turn in a body of water, is splashed with at least 5 gallons of water, or is hit by a water elementals slam attack.
- **Elemental Nature:** An elemental doesnt require air, sustenance, or sleep.
### Actions
- **Multiattack:** The elemental makes two slam attacks.
- **Slam:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 13 (2d8 + 4) fire damage  and the target suffers 5 (1d10) ongoing fire damage. A creature can use an action to end the ongoing damage.
- **Wildfire (Recharge 4-6):** The elemental moves up to half its Speed without provoking opportunity attacks. It can enter the spaces of hostile creatures but not end this movement there. When a creature shares its space with the elemental for the first time during this movement  the creature is subject to the elementals Fiery Aura and the elemental can make a slam attack against that creature.
}}
```