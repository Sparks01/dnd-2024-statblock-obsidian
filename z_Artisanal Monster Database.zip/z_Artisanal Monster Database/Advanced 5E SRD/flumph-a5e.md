```monsterwide
{{monster,frame,wide
## Flumph
*Small aberration*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 7 (2d6)
**Speed**      :: 5 ft. fly 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** psychic
**Senses**      :: darkvision 60 ft., passive Perception 12
**Languages**   :: understands Common and Undercommon but can't speak, telepathy 60 ft.
**CR**          :: 1/8 (PB +2)
}}
### Traits
- **Amphibious:** The flumph can breathe air and water.
- **Flumph Light:** As a bonus action, the flumph can cast dim light for 30 feet, or extinguish its glow. The flumph can change the color of the light it casts at will.
- **Telepathic Spy:** The flumph can perceive any telepathic messages sent or received within 60 feet, and can't be surprised by creatures with telepathy. The flumph is also immune to divination and to any effect that would sense its emotions or read its thoughts, except for the Telepathic Spy feature of another flumph.
- **Tippable:** If a flumph is knocked prone, it lands upside down and is incapacitated. At the end of each of its turns, it can make a DC 10 Dexterity saving throw, flipping itself over and ending the incapacitated condition on a success.
### Actions
- **Tendrils:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 1 piercing damage plus 3 (1d6) acid damage.
- **Stench Spray (1/Day):** Each creature in a 15-foot cone makes a DC 10 Dexterity saving throw. On a failure  the creature exudes a horrible stench for 1 hour. While a creature exudes this stench  it and any creature within 5 feet of it are poisoned. A creature can remove the stench on itself by bathing during a rest.
}}
```