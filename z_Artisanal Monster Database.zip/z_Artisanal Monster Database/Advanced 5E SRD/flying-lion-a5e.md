```monsterwide
{{monster,frame,wide
## Flying Lion
*Large Monstrosity*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 57 (6d10+24)
**Speed**      :: 30 ft. fly 80 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +5
**Senses**      :: passive Perception 15
**Languages**   :: ### Special Abilities
**CR**          :: 3 (PB +2)
}}
### Traits
- **Keen Smell:** The flying lion has advantage on Perception checks that rely on smell.
### Actions
- **Multiattack:** The griffon attacks once with its beak and once with its talons.
- **Bite:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 9 (2d4 + 4) piercing damage.
- **Talons:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 7 (1d6 + 4) slashing damage  or 11 (2d6 + 4) slashing damage if the griffon started its turn at least 20 feet above the target  and the target is grappled (escape DC 14). Until this grapple ends  the griffon can't attack a different target with its talons.
}}
```