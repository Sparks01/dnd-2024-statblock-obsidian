```monsterwide
{{monster,frame,wide
## Flying Snake
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 7 (2d4+2)
**Speed**      :: 30 ft. fly 60 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 10 ft., passive Perception 11
**Senses**      :: blindsight 10 ft., passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 1/8 (PB +2)
}}
### Traits
- **Flyby:** The snake doesnt provoke opportunity attacks when it flies out of a creatures reach.
### Actions
- **Bite:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 1 piercing damage plus 3 (1d6) poison damage.
}}
```