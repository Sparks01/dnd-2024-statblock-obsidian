```monsterwide
{{monster,frame,wide
## Flying Sword
*Small Construct*
{{stats
{{vitals
**AC**         :: 17
**HP**         :: 10 (3d6)
**Speed**      :: 0 ft. fly 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison, psychic
**Senses**      :: blindsight 60 ft. (blind beyond this radius), passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Spell-created:** The DC for dispel magic to destroy this creature is 19.
- **False Appearance:** While motionless, the sword is indistinguishable from a normal sword.
### Actions
- **Longsword:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 5 (1d8 + 1) slashing damage.
}}
```