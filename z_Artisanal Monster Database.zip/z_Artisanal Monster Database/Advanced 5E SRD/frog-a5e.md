```monsterwide
{{monster,frame,wide
## Frog
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 1 (1d4-1)
**Speed**      :: 20 ft. swim 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +3
**Senses**      :: darkvision 30 ft., passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Amphibious:** The frog can breathe air and water.
- **Jumper:** The frog can jump up to 10 feet horizontally and 5 feet vertically without a running start.
}}
```