```monsterwide
{{monster,frame,wide
## Gelatinous Cube
*Large Ooze*
{{stats
{{vitals
**AC**         :: 6
**HP**         :: 76 (8d10+32)
**Speed**      :: 15 ft. swim 15 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Condition Immunities:** blinded, charmed, deafened, fatigue, frightened, prone
**Senses**      :: blindsight 60 ft. (blind beyond this radius), passive Perception 8
**Languages**   :: ### Special Abilities
**CR**          :: 2 (PB +2)
}}
### Traits
- **Engulfing Body:** A creature that enters the cubes space is subjected to the saving throw and consequences of its Engulf attack.
- **Sunlight Sensitivity:** While in sunlight, the cube has disadvantage on attack rolls.
- **Transparent:** While the cube is motionless, creatures unaware of its presence must succeed on a DC 15 Perception check to spot it.
- **Ooze Nature:** An ooze doesnt require air or sleep.
### Actions
- **Pseudopod:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 10 (3d6) acid damage.
- **Engulf:** The cube moves up to its Speed. While doing so  it can enter Large or smaller creatures spaces. Whenever the cube enters a creatures space  the creature makes a DC 13 Dexterity saving throw. If the creature is unaware of the cubes presence  it makes its saving throw against Engulf with disadvantage. On a success  the creature may use its reaction  if available  to move up to half its Speed without provoking opportunity attacks. If the creature doesnt move  it is engulfed by the cube.
- **A creature engulfed by the cube takes 10 (3d6) acid damage, can't breathe, is restrained, and takes 10 (3d6) acid damage at the start of each of the cubes turns:** It can be seen but has total cover. It moves with the cube. The cube can hold as many creatures as fit in its space without squeezing.
- **An engulfed creature can escape by using an action to make a DC 13 Strength check:** On a success  the creature moves to a space within 5 feet of the cube. A creature within 5 feet can take the same action to free an engulfed creature  but takes 10 (3d6) acid damage in the process.
}}
```