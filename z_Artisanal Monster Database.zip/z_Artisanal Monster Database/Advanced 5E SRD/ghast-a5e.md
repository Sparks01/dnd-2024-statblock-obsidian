```monsterwide
{{monster,frame,wide
## Ghast
*Medium Undead*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 36 (8d8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Common
**CR**          :: 2 (PB +2)
}}
### Traits
- **Stench:** A creature that starts its turn within 5 feet of the ghast makes a DC 10 Constitution saving throw. On a failure, it is poisoned until the start of its next turn. On a success, it is immune to any ghasts Stench for 24 hours.
- **Turning Defiance:** The ghast and any ghouls within 30 feet make saving throws against being turned with advantage.
- **Undead Nature:** Ghouls and ghasts dont require air, sustenance, or sleep.
### Actions
- **Paralyzing Claw:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 7 (1d8 + 3) slashing damage. If the target is a living creature  it makes a DC 10 Constitution saving throw. On a failure  the target is paralyzed for 1 minute. The target repeats the saving throw at the end of its turns  ending the effect on itself on a success. If the targets saving throw is successful or the effect ends for it  it is immune to any Paralyzing Claw for 24 hours.
- **Bite:** Melee Weapon Attack: +5 to hit, reach 5 ft., one incapacitated creature. Hit: 8 (1d10 + 3) piercing damage.
}}
```