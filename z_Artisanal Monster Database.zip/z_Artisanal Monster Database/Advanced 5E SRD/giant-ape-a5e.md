```monsterwide
{{monster,frame,wide
## Giant Ape
*Huge Beast*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 115 (11d12+44)
**Speed**      :: 40 ft. climb 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +8, perception +4
**Senses**      :: passive Perception 14
**Languages**   :: ### Actions
**CR**          :: 7 (PB +2)
}}
### Actions
- **Multiattack:** The ape attacks twice with its fists.
- **Fists:** Melee Weapon Attack: +8 to hit, reach 10 ft., one target. Hit: 21 (3d10+5) bludgeoning damage.
- **Rock:** Ranged Weapon Attack: +8 to hit, range 50/100 ft., one target. Hit: 26 (6d6+5) bludgeoning damage.
}}
```