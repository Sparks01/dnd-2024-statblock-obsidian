```monsterwide
{{monster,frame,wide
## Giant Badger
*Medium Beast*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 19 (3d8+6)
**Speed**      :: 30 ft. burrow 10 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 30 ft., passive Perception 11
**Senses**      :: darkvision 30 ft., passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Keen Smell:** The badger has advantage on Perception checks that rely on smell.
### Actions
- **Bite:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 4 (1d6+1) piercing damage.
}}
```