```monsterwide
{{monster,frame,wide
## Giant Bat
*Large Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 16 (3d10)
**Speed**      :: 10 ft. fly 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 60 ft., passive Perception 11
**Senses**      :: blindsight 60 ft., passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Echolocation:** The bat can't use blindsight while deafened.
- **Keen Hearing:** The bat has advantage on Perception checks that rely on hearing.
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6+2) piercing damage.
}}
```