```monsterwide
{{monster,frame,wide
## Giant Boar
*Large Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 47 (5d10+20)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 9
**Senses**      :: passive Perception 9
**Languages**   :: ### Special Abilities
**CR**          :: 2 (PB +2)
}}
### Traits
- **Relentless (1/Day):** If the boar takes 10 or less damage that would reduce it to 0 hit points, it is instead reduced to 1 hit point.
### Actions
- **Tusk:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 10 (2d6+3) slashing damage. If the boar moves at least 20 feet straight towards the target before the attack  the attack deals an extra 7 (2d6) slashing damage and the target makes a DC 13 Strength saving throw  falling prone on a failure.
}}
```