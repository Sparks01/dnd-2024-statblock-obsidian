```monsterwide
{{monster,frame,wide
## Giant Constrictor Snake
*Huge Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 52 (7d12+7)
**Speed**      :: 30 ft. climb 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2
**Senses**      :: blindsight 10 ft., passive Perception 12
**Languages**   :: ### Actions
**CR**          :: 2 (PB +2)
}}
### Actions
- **Bite:** Melee Weapon Attack: +6 to hit, reach 10 ft., one target. Hit: 13 (2d8+4) piercing damage.
- **Constrict:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 11 (2d6+4) bludgeoning damage and the target is grappled (escape DC 16). Until this grapple ends  the target is restrained and the snake can't constrict a different target.
}}
```