```monsterwide
{{monster,frame,wide
## Giant Crab
*Medium Beast*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 9 (2d8)
**Speed**      :: 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +4
**Senses**      :: blindsight 30 ft., passive Perception 9
**Languages**   :: ### Special Abilities
**CR**          :: 1/8 (PB +2)
}}
### Traits
- **Amphibious:** The crab can breathe air and water.
### Actions
- **Claw:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 4 (1d6+1) bludgeoning damage and the target is grappled (escape DC 11). The crab has two claws and can grapple one creature with each.
}}
```