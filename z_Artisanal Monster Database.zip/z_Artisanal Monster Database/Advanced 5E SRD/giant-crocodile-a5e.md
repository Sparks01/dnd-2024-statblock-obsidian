```monsterwide
{{monster,frame,wide
## Giant Crocodile
*Huge Beast*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 85 (9d12+27)
**Speed**      :: 30 ft. swim 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +3
**Senses**      :: passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 5 (PB +2)
}}
### Traits
- **Hold Breath:** The crocodile can hold its breath for 30 minutes.
### Actions
- **Multiattack:** The crocodile attacks with its bite and its tail.
- **Bite:** Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 16 (2d10+5) piercing damage and the target is grappled (escape DC 15). Until this grapple ends  the target is restrained and the crocodile can't bite a different target.
- **Tail:** Melee Weapon Attack: +8 to hit, reach 10 ft., one creature not grappled by the crocodile. Hit: 14 (2d8+5) bludgeoning damage and the target makes a DC 18 Strength saving throw  falling prone on a failure.
}}
```