```monsterwide
{{monster,frame,wide
## Giant Eagle
*Large Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 26 (4d10+4)
**Speed**      :: 10 ft. fly 80 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +4
**Senses**      :: passive Perception 14
**Languages**   :: Giant Eagle, understands but can't speak Common and Auran
**CR**          :: 1 (PB +2)
}}
### Traits
- **Keen Sight:** The eagle has advantage on Perception checks that rely on sight.
### Actions
- **Talons:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 9 (2d6+2) slashing damage and the target is grappled (escape DC 13). Until this grapple ends  the giant eagle can't attack a different target with its talons.
### Bonus Actions
- **Beak:** Melee Weapon Attack: +4 to hit, reach 5 ft., one grappled creature. Hit: 5 (1d6+2) piercing damage.
}}
```