```monsterwide
{{monster,frame,wide
## Giant Elk
*Huge Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 42 (5d12+10)
**Speed**      :: 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 12
**Senses**      :: passive Perception 12
**Languages**   :: Giant Elk, understands but can't speak Common, Elvish, and Sylvan
**CR**          :: 2 (PB +2)
}}
### Actions
- **Ram:** Melee Weapon Attack: +6 to hit, reach 10 ft., one target. Hit: 11 (2d6+4) bludgeoning damage. If the target is a creature and the elk moves at least 20 feet straight towards the target before the attack  the target makes a DC 14 Strength saving throw  falling prone on a failure.
### Bonus Actions
- **Hooves:** Melee Weapon Attack: +6 to hit, reach 5 ft., one prone creature. Hit: 9 (2d4+4) bludgeoning damage.
}}
```