```monsterwide
{{monster,frame,wide
## Giant Fire Beetle
*Small Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 4 (1d6+1)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 30 ft., passive Perception 8
**Senses**      :: blindsight 30 ft., passive Perception 8
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Fire Glands:** The beetle sheds bright light in a 10-foot radius and dim light for an additional 10 feet.
### Actions
- **Bite:** Melee Weapon Attack: +1 to hit, reach 5 ft., one target. Hit: 1 slashing damage.
}}
```