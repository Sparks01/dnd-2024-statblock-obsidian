```monsterwide
{{monster,frame,wide
## Giant Lizard
*Large Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 19 (3d10+3)
**Speed**      :: 30 ft. climb 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 30 ft., passive Perception 10
**Senses**      :: darkvision 30 ft., passive Perception 10
**Languages**   :: ### Actions
**CR**          :: 1/4 (PB +2)
}}
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 4 (1d4+2) piercing damage.
}}
```