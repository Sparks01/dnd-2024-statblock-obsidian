```monsterwide
{{monster,frame,wide
## Giant Owl
*Large Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 19 (3d10+3)
**Speed**      :: 5 ft. fly 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +4, stealth +4
**Senses**      :: darkvision 120 ft., passive Perception 14
**Languages**   :: Giant Owl; understands but can't speak Common, Elvish, and Sylvan
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Flyby:** The owl doesnt provoke opportunity attacks when it flies out of a creatures reach.
- **Keen Hearing and Sight:** The owl has advantage on Perception checks that rely on hearing and sight.
### Actions
- **Talons:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 4 (1d6+1) slashing damage.
}}
```