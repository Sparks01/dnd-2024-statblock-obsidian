```monsterwide
{{monster,frame,wide
## Giant Scorpion
*Large Beast*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 52 (7d10+14)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 60 ft., passive Perception 9
**Senses**      :: blindsight 60 ft., passive Perception 9
**Languages**   :: ### Actions
**CR**          :: 3 (PB +2)
}}
### Actions
- **Multiattack:** The scorpion attacks once with its claws and once with its sting.
- **Claws:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 9 (2d6+2) bludgeoning damage and the target is grappled (escape DC 12). Until this grapple ends  the scorpion can't attack a different target with its claws.
- **Sting:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 6 (1d8+2) piercing damage and the target makes a DC 12 Constitution saving throw  taking 16 (3d10) poison damage on a failure or half damage on a success.
}}
```