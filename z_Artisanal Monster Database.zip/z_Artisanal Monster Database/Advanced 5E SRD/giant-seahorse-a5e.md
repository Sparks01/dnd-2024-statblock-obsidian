```monsterwide
{{monster,frame,wide
## Giant Seahorse
*Large Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 22 (4d10)
**Speed**      :: 0 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 11
**Senses**      :: passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Water Breathing:** The seahorse breathes only water.
### Actions
- **Ram:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 6 (2d4+1) bludgeoning damage. If the seahorse moves at least 20 feet straight towards the target before the attack  the attack deals an extra 5 (2d4) bludgeoning damage and the target makes a DC 11 Strength saving throw  falling prone on a failure.
}}
```