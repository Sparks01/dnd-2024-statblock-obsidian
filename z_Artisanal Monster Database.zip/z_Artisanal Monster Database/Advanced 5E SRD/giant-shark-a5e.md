```monsterwide
{{monster,frame,wide
## Giant Shark
*Huge Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 105 (10d12+40)
**Speed**      :: 0 ft. swim 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: blindsight 60 ft., passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 5 (PB +2)
}}
### Traits
- **Water Breathing:** The shark breathes only water.
### Actions
- **Bite:** Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 21 (3d10+5) piercing damage. On a hit  the shark can make a second bite attack as a bonus action.
- **Tail:** Melee Weapon Attack: +8 to hit, reach 10 ft., one target. Hit: 15 (3d6+5) bludgeoning damage  and the shark can swim 20 feet without provoking opportunity attacks.
}}
```