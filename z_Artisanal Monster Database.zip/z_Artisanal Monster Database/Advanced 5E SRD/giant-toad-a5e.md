```monsterwide
{{monster,frame,wide
## Giant Toad
*Large Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 33 (6d10)
**Speed**      :: 20 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 30 ft., passive Perception 10
**Senses**      :: darkvision 30 ft., passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 1 (PB +2)
}}
### Traits
- **Amphibious:** The toad can breathe air and water.
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6+2) piercing damage plus 4 (1d8) poison damage and the target is grappled (escape DC 12). Until this grapple ends  the toad can't bite another target.
- **Swallow:** The toad makes a bite attack against a Medium or smaller creature it is grappling. If the attack hits and the toad has not swallowed another creature  the target is swallowed and the grapple ends. A swallowed creature has total cover from attacks from outside the toad  it is blinded and restrained  and it takes 7 (2d6) acid damage at the beginning of each of the toads turns. If the toad dies  the target is no longer swallowed.
- **Vaulting Leap:** The toad jumps up to 20 feet horizontally and 10 feet vertically. If its within 5 feet of a creature that it is not grappling at the end of this movement  it can make a bite attack against that creature with advantage.
}}
```