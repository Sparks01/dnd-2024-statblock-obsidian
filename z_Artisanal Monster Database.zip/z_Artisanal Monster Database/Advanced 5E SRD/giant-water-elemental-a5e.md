```monsterwide
{{monster,frame,wide
## Giant Water Elemental
*Huge elemental*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 157 (15d12+60)
**Speed**      :: 30 ft. swim 90 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Aquan
**CR**          :: 9 (PB +2)
}}
### Traits
- **Conductive:** If the elemental takes lightning damage, each creature sharing its space takes the same amount of lightning damage.
- **Fluid Form:** The elemental can enter and end its turn in other creatures spaces and move through a space as narrow as 1 inch wide without squeezing.
- **Freeze:** If the elemental takes cold damage, its speed is reduced by 15 feet until the end of its next turn.
### Actions
- **Multiattack:** The elemental makes two slam attacks.
- **Slam:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 22 (4d8 + 4) bludgeoning damage.
- **Whelm:** The elemental targets each Large or smaller creature in its space. Each target makes a DC 15 Strength saving throw. On a failure  the target is grappled (escape DC 15). Until this grapple ends  the target is restrained and unable to breathe air. The elemental can move at full speed while carrying grappled creatures inside its space. It can grapple one Large creature or up to four Medium or smaller creatures.
}}
```