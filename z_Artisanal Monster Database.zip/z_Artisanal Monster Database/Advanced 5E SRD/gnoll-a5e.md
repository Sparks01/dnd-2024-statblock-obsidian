```monsterwide
{{monster,frame,wide
## Gnoll
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 22 (5d8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 60 ft., passive Perception 9
**Senses**      :: darkvision 60 ft., passive Perception 9
**Languages**   :: Gnoll
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Pack Tactics:** The gnoll has advantage on attack rolls against a creature if at least one of the gnolls allies is within 5 feet of the creature and not incapacitated.
### Actions
- **Spear:** Melee or Ranged Weapon Attack: +4 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 5 (1d6 + 2) piercing damage.
### Bonus Actions
- **Rampaging Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one bloodied creature. Hit: 4 (1d4 + 2) piercing damage.
}}
```