```monsterwide
{{monster,frame,wide
## Gnoll Demonfang
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 65 (10d8+20)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Condition Immunities:** charmed, frightened
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Abyssal, Gnoll
**CR**          :: 4 (PB +2)
}}
### Traits
- **Aligned:** The gnoll radiates a Chaotic and Evil aura.
- **Possessed:** If the gnoll demonfang is turned or affected by dispel evil and good or a similar effect, it transforms into an ordinary gnoll. Any damage it has taken carries over to its new form. If this damage exceeds its maximum hit points, it dies.
### Actions
- **Multiattack:** The gnoll attacks three times with its Charging Claw.
- **Charging Claw:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 6 (1d6 + 3) slashing damage  or 10 (2d6 + 3) slashing damage if this is the gnolls first attack on this target this turn. The gnoll may then move up to 10 feet without provoking opportunity attacks.
}}
```