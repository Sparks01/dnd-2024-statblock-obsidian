```monsterwide
{{monster,frame,wide
## Goat
*Medium Beast*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 4 (1d8)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +2
**Senses**      :: passive Perception 10
**Languages**   :: ### Actions
**CR**          :: 0 (PB +2)
}}
### Actions
- **Ram:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 2 (1d4) bludgeoning damage. If the target is a creature and the goat moves at least 20 feet straight towards the target before the attack  the target takes an extra 2 (1d4) bludgeoning damage and makes a DC 10 Strength saving throw  falling prone on a failure.
}}
```