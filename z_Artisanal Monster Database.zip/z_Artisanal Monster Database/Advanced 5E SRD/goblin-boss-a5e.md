```monsterwide
{{monster,frame,wide
## Goblin Boss
*Small humanoid*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 24 (7d6)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +4, intimidation +3
**Senses**      :: darkvision 60 ft., passive Perception 11
**Languages**   :: Common, Goblin
**CR**          :: 1 (PB +2)
}}
### Actions
- **Multiattack:** The goblin attacks twice with its scimitar.
- **Scimitar:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6 + 2) slashing damage.
- **Shortbow:** Ranged Weapon Attack: +4 to hit, range 80/320 ft., one target. Hit: 5 (1d6 + 2) piercing damage.
- **Command Minions:** Up to 3 goblins within 30 feet that can hear or see it use their reactions to make a single melee attack each.
### Bonus Actions
- **Nimble Escape:** The goblin takes the Disengage or Hide action.
}}
```