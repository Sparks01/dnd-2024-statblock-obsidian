```monsterwide
{{monster,frame,wide
## Goblin Musketeer
*Small humanoid*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 10 (3d6)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +3
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Common, Goblin
**CR**          :: 1/2 (PB +2)
}}
### Actions
- **Shortsword:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 4 (1d6 + 1) piercing damage.
- **Two goblin musketeers together can operate a musket:** If one uses its action to assist  the other gains the following additional action:
- **Musket:** Ranged Weapon Attack: +3 to hit, range 60/180 ft., one target. Hit: 10 (2d8 + 1) piercing damage.
### Bonus Actions
- **Nimble Escape:** The goblin takes the Disengage or Hide action.
}}
```