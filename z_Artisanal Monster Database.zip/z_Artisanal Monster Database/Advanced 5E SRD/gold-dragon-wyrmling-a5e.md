```monsterwide
{{monster,frame,wide
## Gold Dragon Wyrmling
*Medium Dragon*
{{stats
{{vitals
**AC**         :: 17
**HP**         :: 75 (10d8+30)
**Speed**      :: 30 ft. fly 60 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +4
**Senses**      :: blindsight 10 ft., darkvision 60 ft., passive Perception 13
**Languages**   :: Draconic
**CR**          :: 4 (PB +2)
}}
### Actions
- **Bite:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 9 (1d10 + 4) piercing damage.
- **Breath Weapons (Recharge 5-6):** The dragon uses one of the following breath weapons:
- **Molten Breath:** The dragon exhales molten gold in a 15-foot cone. Each creature in the area makes a DC 13 Dexterity saving throw  taking 22 (4d10) fire damage on a failed save or half damage on a success.
- **Slowing Breath:** The dragon exhales gas in a 15-foot cone. Each creature in the area must succeed on a DC 13 Strength saving throw or suffer disadvantage on weapon attack rolls for 1 minute. A weakened creature repeats the saving throw at the end of each of its turns  ending the effect on a success.
}}
```