```monsterwide
{{monster,frame,wide
## Gray Ooze
*Medium Ooze*
{{stats
{{vitals
**AC**         :: 8
**HP**         :: 22 (3d8+9)
**Speed**      :: 15 ft. climb 15 ft. swim 15 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Resistances:** acid, cold, fire
**Senses**      :: blindsight 60 ft. (blind beyond this radius), passive Perception 8
**Languages**   :: ### Special Abilities
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Amorphous:** The ooze can pass through an opening as narrow as 1 inch wide without squeezing.
- **Corrosive Body:** A creature or a metal object that touches the ooze takes 5 (2d4) acid damage. A nonmagical weapon made of metal that hits the black pudding corrodes after dealing damage, taking a permanent -1 penalty to damage rolls per hit. If this penalty reaches -5, the weapon is destroyed. Metal nonmagical ammunition is destroyed after dealing damage.
- **False Appearance:** While motionless, the ooze is indistinguishable from wet stone.
- **Sunlight Sensitivity:** While in sunlight, the ooze has disadvantage on attack rolls.
- **Ooze Nature:** An ooze doesnt require air or sleep.
### Actions
- **Pseudopod:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 3 (1d4 + 1) bludgeoning damage plus 5 (2d4) acid damage. Nonmagical metal armor worn by the target corrodes  taking a permanent -1 penalty to its AC protection per hit. If the penalty reduces the armors AC protection to 10  the armor is destroyed.
}}
```