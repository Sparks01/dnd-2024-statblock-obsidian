```monsterwide
{{monster,frame,wide
## Hawk
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 1 (1d4-1)
**Speed**      :: 10 ft. fly 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +4
**Senses**      :: passive Perception 14
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Keen Sight:** The hawk has advantage on Perception checks that rely on sight.
### Actions
- **Talons:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 1 slashing damage.
}}
```