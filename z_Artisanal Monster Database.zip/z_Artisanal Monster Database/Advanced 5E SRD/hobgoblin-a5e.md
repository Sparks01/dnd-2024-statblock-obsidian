```monsterwide
{{monster,frame,wide
## Hobgoblin
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 19 (3d8+6)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2, survival +2
**Senses**      :: darkvision 60 ft., passive Perception 12
**Languages**   :: Common, Goblin
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Formation Movement:** If the hobgoblin begins its turn within 5 feet of an ally that is not incapacitated, its movement doesnt provoke opportunity attacks.
### Actions
- **Longsword:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 5 (1d8 + 1) slashing damage  or 10 (2d8 + 1) slashing damage if within 5 feet of an ally that is not incapacitated.
- **Longbow:** Ranged Weapon Attack: +3 to hit, range 150/600 ft., one target. Hit: 5 (1d8 + 1) piercing damage.
}}
```