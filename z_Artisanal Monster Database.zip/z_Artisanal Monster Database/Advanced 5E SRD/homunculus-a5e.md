```monsterwide
{{monster,frame,wide
## Homunculus
*Tiny Construct*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 5 (2d4)
**Speed**      :: 20 ft. fly 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: understands the languages of its creator but can't speak
**CR**          :: 0 (PB +2)
}}
### Traits
- **Telepathic Bond:** While they are on the same plane, the homunculus and its creator can communicate telepathically at any distance.
### Actions
- **Bite:** Melee Weapon Attack: +5 to hit, reach 5 ft., one creature. Hit: 1 piercing damage  and the target makes a DC 10 Constitution saving throw. On a failure  it is poisoned. At the end of its next turn  it repeats the saving throw. On a success  the effect ends. On a failure  it falls unconscious for 1 minute. If it takes damage or a creature uses an action to shake it awake  it wakes up  and the poisoned effect ends.
}}
```