```monsterwide
{{monster,frame,wide
## Horde Demon Band
*Large Fiend*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 260 (40d8+80)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison
**Senses**      :: darkvision 120 ft., passive Perception 11
**Languages**   :: Abyssal
**CR**          :: 13 (PB +2)
}}
### Traits
- **Area Vulnerability:** The band takes double damage from any effect that targets an area.
- **Chaotic Evil:** The band radiates a Chaotic and Evil aura.
- **Band:** The band is composed of 5 or more horde demons. If it is subjected to a spell, attack, or other effect that affects only one target, it takes any damage but ignores other effects. It can share its space with Medium or smaller creatures or objects. The band can move through any opening large enough for one Medium creature without squeezing.
- **Band Dispersal:** When the band is reduced to 0 hit points, it turns into 2 (1d4) horde demons with 26 hit points each.
### Actions
- **Multiattack:** The band attacks twice.
- **Mob Attack:** Melee Weapon Attack: +8 to hit, reach 5 ft., one creature. Hit: 50 (10d6 + 15) slashing damage  or half damage if the band is bloodied.
}}
```