```monsterwide
{{monster,frame,wide
## Hound Guardian
*Medium Construct*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 32 (5d8+10)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: darkvision 60 ft., passive Perception 13
**Languages**   :: understands the languages of its creator but can't speak
**CR**          :: 1 (PB +2)
}}
### Traits
- **Immutable Form:** The guardian is immune to any effect that would alter its form.
- **Keen Hearing and Smell:** The guardian has advantage on Perception checks that rely on hearing or smell.
- **Magic Resistance:** The guardian has advantage on saving throws against spells and magical effects.
- **Constructed Nature:** Guardians dont require air, sustenance, or sleep.
### Actions
- **Bite:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 8 (2d4 + 3) piercing damage. If the target is a creature  it makes a DC 13 Strength saving throw  falling prone on a failure.
### Reactions
- **Protective Bite:** When a creature within 5 feet hits the guardians owner with a melee attack, the guardian bites the attacker.
}}
```