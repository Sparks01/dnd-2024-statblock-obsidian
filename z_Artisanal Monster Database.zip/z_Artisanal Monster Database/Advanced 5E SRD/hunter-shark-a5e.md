```monsterwide
{{monster,frame,wide
## Hunter Shark
*Large Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 45 (6d10+12)
**Speed**      :: 0 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2
**Senses**      :: blindsight 30 ft., passive Perception 12
**Languages**   :: ### Special Abilities
**CR**          :: 2 (PB +2)
}}
### Traits
- **Water Breathing:** The shark breathes only water.
### Actions
- **Bite:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 11 (2d6+4) piercing damage. On a hit  the shark can use a bonus action to make a second bite attack.
}}
```