```monsterwide
{{monster,frame,wide
## Hydra
*Huge Monstrosity*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 172 (15d12+75)
**Speed**      :: 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +5, stealth +5
**Senses**      :: darkvision 60 ft., passive Perception 15
**Languages**   :: ### Special Abilities
**CR**          :: 9 (PB +2)
}}
### Traits
- **Hold Breath:** The hydra can hold its breath for 1 hour.
- **Legendary Resistance (3/Day):** When the hydra fails a saving throw, it can choose to succeed instead. When it does so, its heads lose coordination. It is rattled until the end of its next turn.
- **Multiple Heads:** While the hydra has more than one head, it has advantage on Perception checks and on saving throws against being blinded, charmed, deafened, frightened, stunned, and knocked unconscious, and it can't be flanked.
- **Reactive Heads:** For each head it has, the hydra can take one reaction per round, but not more than one per turn.
- **Regenerating Heads:** The hydra has five heads. Whenever the hydra takes 25 or more damage in one turn, one of its heads dies. If all of its heads die, the hydra dies. At the end of its turn, it grows 2 heads for each head that was killed since its last turn, unless it has taken fire damage since its last turn.
- **Toxic Secretions:** Water within 1 mile of the hydras lair is poisoned. A creature other than the hydra that is immersed in the water or drinks the water makes a DC 17 Constitution saving throw. On a failure, the creature is poisoned for 24 hours. On a success, the creature is immune to this poison for 24 hours.
- **Wakeful:** When some of the hydras heads are asleep, others are awake.
### Actions
- **Multiattack:** The hydra bites once with each of its heads.
- **Bite:** Melee Weapon Attack: +9 to hit, reach 15 ft., one target. Hit: 10 (1d10 + 5) piercing damage.
### Legendary Actions
- **The hydra can take 2 legendary actions:** Only one legendary action can be used at a time and only at the end of another creatures turn. It regains spent legendary actions at the start of its turn.
- **Rush:** The hydra moves or swims up to half its Speed without provoking opportunity attacks. If this movement would pass through the space of creatures that are not incapacitated or prone, each creature makes a DC 17 Strength saving throw. On a failure, the creature is knocked prone and the hydra can enter its space without treating it as difficult terrain. On a success, the hydra can't enter the creatures space, and the hydras movement ends. If this movement ends while the hydra is sharing a space with a creature, the creature is pushed to the nearest unoccupied space.
- **Wrap:** Melee Weapon Attack: +9 to hit, reach 10 ft., one Medium or smaller creature. Hit: The target is grappled (escape DC 17) and restrained until this grappled ends. The hydra can grapple one creature for each of its heads. When one of the hydras heads is killed while it is grappling a creature, the creature that killed the head can choose one creature to free from the grapple.
}}
```