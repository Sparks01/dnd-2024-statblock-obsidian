```monsterwide
{{monster,frame,wide
## Hyena
*Medium Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 4 (1d8)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: darkvision 30 ft., passive Perception 13
**Languages**   :: ### Actions
**CR**          :: 0 (PB +2)
}}
### Actions
- **Bite:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 2 (1d4) piercing damage. If this damage reduces the target to 0 hit points  the hyena can use its bonus action to move half its Speed and make a second bite attack.
}}
```