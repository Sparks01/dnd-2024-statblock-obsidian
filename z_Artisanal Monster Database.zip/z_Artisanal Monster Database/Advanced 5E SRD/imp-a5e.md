```monsterwide
{{monster,frame,wide
## Imp
*Tiny Fiend*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 14 (4d4+4)
**Speed**      :: 20 ft. fly 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: deception +4, insight +3, perception +3, persuasion +4, stealth +5
**Senses**      :: darkvision 120 ft., passive Perception 13
**Languages**   :: Infernal, telepathy 120 ft.
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Devils Sight:** The imps darkvision penetrates magical darkness.
- **Ventriloquism:** The imp can perfectly imitate any voice it has heard. It can make its voice appear to originate from any point within 30 feet.
- **Lawful Evil:** The imp radiates a Lawful and Evil aura.
- **Magic Resistance:** The imp has advantage on saving throws against spells and magical effects.
### Actions
- **Sting (Bite While Shapeshifted):** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 5 (1d4 + 3) piercing damage plus 3 (1d6) poison damage.
- **Shapeshift:** The imp magically changes its form into a rat (speed 20 ft.)  raven (20 ft.  fly 60 ft.)  or spider (20 ft.  climb 20 ft.) or back into its true form. Its statistics are the same in each form except for its movement speeds. Equipment it carries is not transformed. It reverts to its true form if it dies.
### Bonus Actions
- **Invisibility:** The imp magically turns invisible, along with any equipment carried. This invisibility ends if the imp makes an attack, falls unconscious, or dismisses the effect.
}}
```