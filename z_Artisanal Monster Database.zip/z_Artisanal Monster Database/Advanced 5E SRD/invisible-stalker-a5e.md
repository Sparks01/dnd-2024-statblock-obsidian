```monsterwide
{{monster,frame,wide
## Invisible Stalker
*Medium elemental*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 104 (16d8+32)
**Speed**      :: 50 ft. fly 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +5, stealth +7
**Senses**      :: darkvision 60 ft., passive Perception 15
**Languages**   :: Auran, Common
**CR**          :: 6 (PB +2)
}}
### Traits
- **Invisibility:** The stalker is invisible. Creatures that see invisible creatures see the stalker as a vague humanoid outline.
- **Wind Tracker:** If given a quarry by a summoner, the stalker knows the direction and distance to the quarry as long as they are on the same plane of existence and not sealed from each other by a barrier that doesnt allow air to pass.
- **Elemental Nature:** An invisible stalker doesnt require air, sustenance, or sleep.
### Actions
- **Multiattack:** The stalker makes two melee attacks.
- **Slam:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 12 (2d8 + 3) bludgeoning damage. On a critical hit  the target is pushed up to 15 feet and knocked prone.
### Bonus Actions
- **Gust (Recharge 6):** The stalker briefly turns into a gust of wind and moves up to its Speed without provoking opportunity attacks. It is able to pass through an opening as narrow as 1 inch wide without squeezing.
}}
```