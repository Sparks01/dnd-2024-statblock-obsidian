```monsterwide
{{monster,frame,wide
## Jackalope
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 55 (10d4+30)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +2, deception +4, perception +5, stealth +6, survival +5
**Senses**      :: passive Perception 17
**Languages**   :: understands Common but cannot speak
**CR**          :: 3 (PB +2)
}}
### Traits
- **Evasion:** If the jackalope is subjected to an effect that allows it to make a Dexterity saving throw to take only half damage, the jackalope instead takes no damage if it succeeds on the saving throw, and only half damage if it fails.
- **Keen Hearing:** The jackalope has advantage on Perception checks that rely on hearing.
- **Mimicry:** The jackalope can imitate sounds it hears frequently, such as a simple phrase or an animal noise. Recognizing the sounds as imitation requires a DC 14 Insight check.
### Actions
- **Gore:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 8 (1d8+4) piercing damage. If the jackalope moves at least 20 feet straight towards the target before the attack  the attack deals an extra 7 (2d6) piercing damage.
### Bonus Actions
- **Nimble Escape:** The jackalope takes the Disengage or Hide action.
### Reactions
- **Uncanny Dodge:** When an attacker the jackalope can see hits it with an attack, the jackalope halves the attacks damage against it.
}}
```