```monsterwide
{{monster,frame,wide
## Kech
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 30 (5d8+8)
**Speed**      :: 30 ft. climb 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +4, stealth +4, perception +3, survival +3
**Senses**      :: darkvision 60 ft., passive Perception 15
**Languages**   :: Common, Goblin
**CR**          :: 1 (PB +2)
}}
### Actions
- **Strangle:** Melee Weapon Attack: +4 to hit, reach 10 ft., one Medium or smaller creature that is surprised  grappled by the kech  or that can't see the kech. Hit: 9 (2d6 + 2) bludgeoning damage  and the target is pulled 5 feet towards the kech and grappled (escape DC 12). Until this grapple ends  the kech automatically hits with the Strangle attack and the target can't breathe.
- **Claw:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 9 (2d6 + 2) slashing damage.
- **Stealthy Sneak:** The kech moves up to half its Speed without provoking opportunity attacks. It can then attempt to hide.
}}
```