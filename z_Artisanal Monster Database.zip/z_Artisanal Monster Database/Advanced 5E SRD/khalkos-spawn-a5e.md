```monsterwide
{{monster,frame,wide
## Khalkos Spawn
*Tiny aberration*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 27 (6d4+12)
**Speed**      :: 30 ft. fly 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Resistances:** fire, psychic, radiant
**Senses**      :: darkvision 60 ft., passive Perception 12
**Languages**   :: telepathy 120 ft.
**CR**          :: 2 (PB +2)
}}
### Traits
- **Detect Alignment:** The khalkos can detect the presence of creatures within 30 feet that have an alignment trait, and knows the alignment of such creatures.
### Actions
- **Chaos Pheromones:** The khalkos emits a cloud of pheromones into the air in a 10-foot radius. The cloud spreads around corners. Each non-khalkos creature in the area makes a DC 12 Intelligence saving throw. On a failure  the creature is confused for 1 minute. It repeats the saving throw at the end of each of its turns  ending the effect on itself on a success. If the creature makes its saving throw or the condition ends for it  it is immune to the chaos pheromones of khalkos spawn for the next 24 hours.
- **Sting:** Melee Weapon Attack: +5 to hit, reach 5 ft., one creature. Hit: 5 (1d4 + 3) piercing damage plus 3 (1d6) poison damage.
}}
```