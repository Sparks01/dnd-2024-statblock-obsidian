```monsterwide
{{monster,frame,wide
## Killer Whale
*Huge Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 75 (10d12+10)
**Speed**      :: 0 ft. swim 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 120 ft., passive Perception 12
**Senses**      :: blindsight 120 ft., passive Perception 12
**Languages**   :: ### Special Abilities
**CR**          :: 3 (PB +2)
}}
### Traits
- **Echolocation:** The whale can't use blindsight while deafened.
- **Hold Breath:** The whale can hold its breath for 30 minutes.
- **Keen Hearing:** The whale has advantage on Perception checks that rely on hearing.
### Actions
- **Bite:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 14 (3d6+4) piercing damage. If the target is a creature  it is grappled (escape DC 14). Until this grapple ends  the whale can't bite another target and it has advantage on bite attacks against the creature it is grappling.
}}
```