```monsterwide
{{monster,frame,wide
## Kobold Broodguard
*Small humanoid*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 44 (8d6+16)
**Speed**      :: 25 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 60 ft., passive Perception 10
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Common, Draconic
**CR**          :: 2 (PB +2)
}}
### Traits
- **Pack Tactics:** The kobold has advantage on attack rolls against a creature if at least one of the kobolds allies is within 5 feet of the creature and not incapacitated.
- **Sunlight Sensitivity:** While in sunlight, the kobold has disadvantage on attack rolls, as well as on Perception checks that rely on sight.
### Actions
- **Multiattack:** The kobold makes a bill hook attack and a spiked shield attack.
- **Bill Hook:** Melee Weapon Attack: +4 to hit, reach 10 ft., one target. Hit: 5 (1d6 + 2) slashing damage  and if the target is a Medium or smaller creature  it makes a DC 12 Strength saving throw  falling prone on a failure.
- **Spiked Shield:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6 + 2) piercing damage.
- **Sling:** Ranged Weapon Attack: +4 to hit, range 30/120 ft., one target. Hit: 4 (1d4 + 2) bludgeoning damage.
### Reactions
- **Rally! (1/Day:** When the kobold takes damage, it shouts a rallying cry. All kobolds within 30 feet that can hear it gain immunity to the frightened condition for 1 minute, and their next attack roll made before this effect ends deals an extra 1d4 damage.
}}
```