```monsterwide
{{monster,frame,wide
## Lacedon
*Medium Undead*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 22 (5d8)
**Speed**      :: 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Common
**CR**          :: 1 (PB +2)
}}
### Traits
- **Radiant Sensitivity:** When the ghoul takes radiant damage, it has disadvantage on attack rolls and on Perception checks that rely on sight until the end of its next turn.
- **Undead Nature:** Ghouls and ghasts dont require air, sustenance, or sleep.
### Actions
- **Paralyzing Claw:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6 + 2) slashing damage. If the target is a living creature other than an elf  it makes a DC 10 Constitution saving throw. On a failure  the target is paralyzed for 1 minute. The target repeats the saving throw at the end of its turns  ending the effect on itself on a success. If the targets saving throw is successful or the effect ends for it  it is immune to any Paralyzing Claw for 24 hours.
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one incapacitated creature. Hit: 6 (1d8 + 2) piercing damage.
}}
```