```monsterwide
{{monster,frame,wide
## Lemure
*Medium Fiend*
{{stats
{{vitals
**AC**         :: 7
**HP**         :: 13 (3d8)
**Speed**      :: 15 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** fire, poison
**Senses**      :: darkvision 120 ft., passive Perception 10
**Languages**   :: understands Infernal but can't speak
**CR**          :: 1/8 (PB +2)
}}
### Traits
- **Devils Sight:** The lemures darkvision penetrates magical darkness.
- **Eerie Groan:** While the lemure can see a non-devil within 100 feet, it emits a groan that is audible within 300 feet.
- **Lawful Evil:** The lemure radiates a Lawful and Evil aura.
### Actions
- **Fist:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 2 (1d4) bludgeoning damage.
}}
```