```monsterwide
{{monster,frame,wide
## Lion
*Large Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 30 (4d10+8)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +4
**Senses**      :: passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 1 (PB +2)
}}
### Traits
- **Keen Smell:** The lion has advantage on Perception checks that rely on smell.
- **Long Jump:** The lion can long jump up to 25 feet.
- **Pack Tactics:** The lion has advantage on attack rolls against a creature if at least one of the lions allies is within 5 feet of the creature and not incapacitated.
### Actions
- **Claws:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 7 (1d8+3) slashing damage. If the lion moves at least 20 feet straight towards the target before the attack  the target makes a DC 13 Strength saving throw  falling prone on a failure.
- **Bite:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 8 (1d10+3) piercing damage.
### Bonus Actions
- **Opportune Bite:** The lion makes a bite attack against a prone creature.
}}
```