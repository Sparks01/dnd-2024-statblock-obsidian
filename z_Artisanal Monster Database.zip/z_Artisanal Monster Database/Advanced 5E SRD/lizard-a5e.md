```monsterwide
{{monster,frame,wide
## Lizard
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 2 (1d4)
**Speed**      :: 20 ft. climb 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 30 ft., passive Perception 10
**Senses**      :: darkvision 30 ft., passive Perception 10
**Languages**   :: ### Actions
**CR**          :: 0 (PB +2)
}}
### Actions
- **Bite:** Melee Weapon Attack: +0 to hit, reach 5 ft., one target. Hit: 1 piercing damage. If this damage would reduce a Small or larger target to 0 hit points  the target takes no damage from this attack.
}}
```