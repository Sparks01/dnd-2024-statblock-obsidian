```monsterwide
{{monster,frame,wide
## Lizardfolk
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 22 (4d8+4)
**Speed**      :: 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2, stealth +3, survival +2
**Senses**      :: passive Perception 12
**Languages**   :: Draconic
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Hold Breath:** The lizardfolk can hold its breath for 15 minutes.
### Actions
- **Multiattack:** The lizardfolk attacks with its club and shield.
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6 + 2) piercing damage  or 9 (2d6 + 2) piercing damage if the attack is made with advantage.
- **Club:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 4 (1d4 + 2) bludgeoning damage.
- **Shield:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 4 (1d4 + 2) bludgeoning damage.
- **Javelin:** Melee or Ranged Weapon Attack: +4 to hit, reach 5 ft. or range 30/120 ft., one target. Hit: 5 (1d6 + 2) piercing damage.
}}
```