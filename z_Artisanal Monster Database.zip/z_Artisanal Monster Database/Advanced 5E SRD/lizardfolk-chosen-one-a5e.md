```monsterwide
{{monster,frame,wide
## Lizardfolk Chosen One
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 75 (10d8+30)
**Speed**      :: 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +3, survival +3
**Senses**      :: passive Perception 15
**Languages**   :: Draconic
**CR**          :: 4 (PB +2)
}}
### Traits
- **Aligned:** The lizardfolk radiates either an Evil or Good aura.
- **Hold Breath:** The lizardfolk can hold its breath for 15 minutes.
### Actions
- **Multiattack:** The lizardfolk attacks once with its shield and twice with its trident.
- **Shield:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 5 (1d4 + 3) bludgeoning damage  and the target makes a DC 13 Strength check. On a failure  it is knocked prone.
- **Trident:** Melee or Ranged Weapon Attack: +5 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 10 (2d6 + 3) piercing damage  and the lizardfolk gains temporary hit points equal to half the damage dealt.
### Reactions
- **Supernatural Rebuke (1/Day):** When the lizardfolk is dealt damage by a creature it can see within 60 feet, its attacker makes a DC 13 Dexterity saving throw. On a failure, the attacker takes 11 (2d10) fire or radiant damage (the lizardfolks choice).
}}
```