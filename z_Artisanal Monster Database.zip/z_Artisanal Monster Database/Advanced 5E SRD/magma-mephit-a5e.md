```monsterwide
{{monster,frame,wide
## Magma Mephit
*Small elemental*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 21 (6d6)
**Speed**      :: 30 ft. fly 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2, stealth +3
**Senses**      :: darkvision 60 ft., passive Perception 12
**Languages**   :: Ignan, Terran
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Death Burst:** When the mephit dies, it explodes into lava. Each creature within 5 feet makes a DC 10 Constitution saving throw, taking 4 (1d8) fire damage on a failed save or half damage on a success.
- **False Appearance:** While motionless, the mephit is indistinguishable from a small magma flow.
- **Elemental Nature:** A mephit doesnt require air, sustenance, or sleep.
### Actions
- **Claws:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 3 (1d4 + 1) slashing damage plus 2 (1d4) fire damage.
- **Heat Metal (1/Day):** Ranged Spell Attack: +4 to hit, range 60 ft., one creature wearing or holding a metal object. Hit: 9 (2d8) fire damage. If a creature is holding the object and suffers damage  it makes a DC 10 Constitution saving throw  dropping the object on a failure.
- **Fire Breath (1/Day):** The mephit exhales a 15-foot cone of fire. Each creature in the area makes a DC 10 Constitution saving throw  taking 7 (2d6) fire damage on a failed save or half damage on a success.
}}
```