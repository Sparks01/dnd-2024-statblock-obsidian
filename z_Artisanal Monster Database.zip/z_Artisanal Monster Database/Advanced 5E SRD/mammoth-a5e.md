```monsterwide
{{monster,frame,wide
## Mammoth
*Huge Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 115 (10d12+50)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 10
**Senses**      :: passive Perception 10
**Languages**   :: ### Actions
**CR**          :: 6 (PB +2)
}}
### Actions
- **Gore:** Melee Weapon Attack: +10 to hit, reach 10 ft., one target. Hit: 23 (3d10+7) piercing damage. If the elephant moves at least 20 feet straight towards the target before the attack  the target makes a DC 18 Strength saving throw  falling prone on a failure.
- **Stomp:** Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 23 (3d10+7) bludgeoning damage.
### Bonus Actions
- **Trample:** The mammoth makes a stomp attack against a prone creature.
- **Trunk Fling:** Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 10 (1d6+7) bludgeoning damage. If the target is a Large or smaller creature, it is pushed 10 feet away from the mammoth and knocked prone.
}}
```