```monsterwide
{{monster,frame,wide
## Manticore
*Large Monstrosity*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 68 (8d10+24)
**Speed**      :: 30 ft. fly 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 60 ft., passive Perception 11
**Senses**      :: darkvision 60 ft., passive Perception 11
**Languages**   :: Common
**CR**          :: 3 (PB +2)
}}
### Actions
- **Multiattack:** The manticore attacks with its bite and its claws.
- **Bite:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 6 (1d6 + 3) piercing damage.
- **Claws:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 8 (2d4 + 3) slashing damage. If the manticore moves at least 20 feet straight towards the target before the attack  the target makes a DC 13 Strength saving throw  falling prone on a failure.
- **Tail:** Melee Weapon Attack: +5 to hit, reach 10 ft., one target. Hit: 7 (1d8 + 3) piercing damage.
- **Tail Spike Volley (4/Day):** The manticore fires tail spikes in a 5-foot-wide  60-foot-long line. Each creature in the area makes a DC 12 Dexterity saving throw  taking 14 (4d6) piercing damage on a failure or half damage on a success.
### Reactions
- **Tail Whip:** If a creature the manticore can see hits it with a melee attack, the manticore attacks the attacker with its tail. If it hits, it can fly up to half its fly speed without provoking opportunity attacks from the attacker.
}}
```