```monsterwide
{{monster,frame,wide
## Marilith
*Large Fiend*
{{stats
{{vitals
**AC**         :: 18
**HP**         :: 220 (21d10+105)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison
**Senses**      :: truesight 120 ft., passive Perception 14
**Languages**   :: Abyssal, telepathy 120 ft.
**CR**          :: 16 (PB +2)
}}
### Traits
- **Chaotic Evil:** The marilith radiates a Chaotic and Evil aura.
- **Magic Resistance:** The marilith has advantage on saving throws against spells and magical effects.
### Actions
- **Multiattack:** The marilith makes six attacks with its longswords.
- **Longsword:** Melee Weapon Attack: +10 to hit, reach 5 ft., one target. Hit: 14 (2d8 + 5) slashing damage.
### Bonus Actions
- **Tail:** Melee Weapon Attack: +10 to hit, reach 10 ft., one creature. Hit: 10 (2d4 + 5) bludgeoning damage, and the target is grappled (escape DC 19).
- **Teleport:** The marilith magically teleports up to 120 feet to an unoccupied space it can see.
### Reactions
- **Reactive Teleport:** When the marilith is hit or missed by a ranged attack, it uses Teleport. If it teleports within 5 feet of a creature, it can attack with its tail.
}}
```