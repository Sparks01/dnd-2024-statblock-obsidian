```monsterwide
{{monster,frame,wide
## Mastiff
*Medium Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 9 (2d8)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 1/8 (PB +2)
}}
### Traits
- **Keen Hearing and Smell:** The mastiff has advantage on Perception checks that rely on hearing and smell.
### Actions
- **Bite:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 3 (1d4+1) piercing damage. If the target is a creature  it makes a DC 11 Strength saving throw  falling prone on a failure.
}}
```