```monsterwide
{{monster,frame,wide
## Merfolk
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 11 (2d8+2)
**Speed**      :: 10 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2
**Senses**      :: darkvision 30 ft., passive Perception 12
**Languages**   :: Aquan, Common
**CR**          :: 1/8 (PB +2)
}}
### Traits
- **Amphibious:** The merfolk can breathe air and water.
### Actions
- **Trident:** Melee or Ranged Weapon Attack: +2 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 4 (1d8) piercing damage if used with two hands to make a melee attack  or 3 (1d6) piercing damage if thrown.
}}
```