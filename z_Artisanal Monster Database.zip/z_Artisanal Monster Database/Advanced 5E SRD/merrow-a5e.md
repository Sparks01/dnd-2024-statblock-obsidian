```monsterwide
{{monster,frame,wide
## Merrow
*Large Monstrosity*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 45 (6d10+12)
**Speed**      :: 10 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 60 ft., passive Perception 11
**Senses**      :: darkvision 60 ft., passive Perception 11
**Languages**   :: Abyssal, Aquan, Giant, Primordial
**CR**          :: 2 (PB +2)
}}
### Traits
- **Amphibious:** The merrow can breathe air and water.
### Actions
- **Claws:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 11 (2d6 + 4) piercing damage  and the target is grappled (escape DC 14). Until this grapple ends  the merrow can't attack a different creature with its claws.
- **Harpoon:** Melee or Ranged Weapon Attack: +6 to hit, reach 10 ft. or range 20/60 ft., one target. Hit: 11 (2d6 + 4) piercing damage. The target makes a DC 14 Strength saving throw. On a failure  the merrow pulls the target up to 20 feet toward the merrow.
### Bonus Actions
- **Bite:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 6 (1d4 + 4) piercing damage, or 9 (2d4 + 4) piercing damage if the target is grappled.
}}
```