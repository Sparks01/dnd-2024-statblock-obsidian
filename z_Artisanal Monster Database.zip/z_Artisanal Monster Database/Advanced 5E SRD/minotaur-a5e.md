```monsterwide
{{monster,frame,wide
## Minotaur
*Large Monstrosity*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 76 (9d10+27)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +5
**Senses**      :: darkvision 60 ft., passive Perception 18
**Languages**   :: Abyssal, Undercommon
**CR**          :: 4 (PB +2)
}}
### Traits
- **Labyrinthine Recall:** The minotaur can perfectly recall any route it has traveled.
### Actions
- **Greataxe:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 17 (2d12 + 4) slashing damage. The minotaur can choose to make the attack with advantage. If it does so  attacks against it have advantage until the start of its next turn.
- **Gore:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 13 (2d8 + 4) piercing damage. If the minotaur moves at least 10 feet straight towards the target before the attack  the attack deals an extra 9 (2d8) damage  and the target makes a DC 16 Strength saving throw  being pushed up to 10 feet away and falling prone on a failure.
### Bonus Actions
- **Roar of Triumph:** If the minotaur reduced a living creature to 0 hit points since the end of its last turn, it roars and gains 10 (3d6) temporary hit points.
}}
```