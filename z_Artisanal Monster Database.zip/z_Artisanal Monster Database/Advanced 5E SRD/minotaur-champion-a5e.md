```monsterwide
{{monster,frame,wide
## Minotaur Champion
*Huge Monstrosity*
{{stats
{{vitals
**AC**         :: 19
**HP**         :: 262 (21d12+126)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +8
**Senses**      :: darkvision 120 ft., passive Perception 21
**Languages**   :: Abyssal, Undercommon
**CR**          :: 16 (PB +2)
}}
### Traits
- **Labyrinthine Recall:** The minotaur can perfectly recall any route it has traveled.
- **Magic Resistance:** The minotaur has advantage on saving throws against spells and magical effects.
### Actions
- **Multiattack:** The minotaur gores once and attacks twice with its greataxe.
- **Gore:** Melee Weapon Attack: +11 to hit, reach 5 ft., one target. Hit: 19 (3d8 + 6) piercing damage  and the target makes a DC 19 Strength saving throw  being pushed up to 5 feet away and falling prone on a failure. If the minotaur moves at least 10 feet straight towards the target before the attack  the attack deals an extra 13 (3d8) damage.
- **Greataxe:** Melee Weapon Attack: +11 to hit, reach 10 ft., one target. Hit: 25 (3d12 + 6) slashing damage.
- **Fire Breath (Recharge 5-6):** The minotaur exhales fire in a 30-foot cone. Each creature in the area makes a DC 19 Dexterity saving throw  taking 55 (10d10) fire damage on a failed save or half damage on a success.
### Bonus Actions
- **Roar of Triumph:** If the minotaur reduced a living creature to 0 hit points since the end of its last turn, it roars and gains 35 (10d6) temporary hit points.
}}
```