```monsterwide
{{monster,frame,wide
## Miremuck Goblin King
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 62 (8d8+16)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +7, persuasion +8, deception +8
**Senses**      :: darkvision 60 ft., passive Perception 9
**Languages**   :: Common, Goblin
**CR**          :: 3 (PB +2)
}}
### Traits
- **Death Transformation:** When a goblin king is slain,whichever goblin killed them will suddenly transforminto a new goblin king (or queen), their stats replacedwith the goblin kings stats. All surrounding goblinsare inclined thereafter to obey the new goblin king.If a goblin king is slain by a non-goblinoid creature,whichever goblin volunteers for the position first isthe one transformed. Goblins are extremely hesitantto do such a thing, as responsibility and stewardshipare such hard work.
### Actions
- **Rapier:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 6 (1d8 + 1) piercing damage.
- **Charm Person (1/day):** Once per day the goblin king can castcharm personas a 3rd-level spell  allowing him tocharm three creatures within 60 feet. The goblinkings spell save DC is 14.
### Reactions
- **Parry:** The goblin king adds 2 to his AC against onemelee attack that would hit him. To do this the goblinking must see the attacker and be wielding a meleeweapon.
}}
```