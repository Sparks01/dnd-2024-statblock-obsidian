```monsterwide
{{monster,frame,wide
## Mountain Dwarf Soldier
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 19 (3d8+6)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2, survival +2
**Senses**      :: passive Perception 12
**Languages**   :: any one
**CR**          :: 1/2 (PB +2)
}}
### Actions
- **Handaxe:** Melee or Ranged Weapon Attack: +4 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 5 (1d6 + 2) slashing damage  or 9 (2d6 + 2) slashing damage if within 5 feet of an ally that is not incapacitated.
- **Heavy Crossbow:** Ranged Weapon Attack: +3 to hit, range 100/400 ft., one target. Hit: 6 (1d10 + 1) piercing damage.
### Bonus Actions
- **Tactical Movement:** Until the end of the soldiers turn, their Speed is halved and their movement doesnt provoke opportunity attacks.
}}
```