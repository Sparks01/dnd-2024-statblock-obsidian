```monsterwide
{{monster,frame,wide
## Mule
*Medium Beast*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 11 (2d8+2)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 10
**Senses**      :: passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 1/8 (PB +2)
}}
### Traits
- **Beast of Burden:** The mule is considered Large when calculating its carrying capacity.
### Actions
- **Hooves:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 3 (1d4+1) bludgeoning damage.
}}
```