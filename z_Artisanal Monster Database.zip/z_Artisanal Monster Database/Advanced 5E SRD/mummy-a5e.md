```monsterwide
{{monster,frame,wide
## Mummy
*Medium Undead*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 67 (9d8+27)
**Speed**      :: 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** necrotic, poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: the languages it knew in life
**CR**          :: 3 (PB +2)
}}
### Traits
- **Flammable:** After taking fire damage, the mummy catches fire and takes 5 (1d10) ongoing fire damage if it isnt already suffering ongoing fire damage. A creature can use an action to extinguish this fire.
- **Curse: Mummy Rot:** A mummys touch inflicts a dreadful curse called mummy rot. A cursed creature can't regain hit points, and its hit point maximum decreases by an amount equal to the creatures total number of Hit Dice for every 24 hours that elapse. If this curse reduces the targets hit point maximum to 0, the target dies and crumbles to dust. Remove curse and similar magic ends the curse.
### Actions
- **Multiattack:** The mummy uses Dreadful Glare and then attacks with its rotting fist.
- **Dreadful Glare (Gaze):** The mummy targets a creature within 60 feet. The target makes a DC 11 Wisdom saving throw. On a failure  it is magically frightened until the end of the mummys next turn. If the target fails the save by 5 or more  it is paralyzed for the same duration. A target that succeeds on the saving throw is immune to the Dreadful Glare of mummies (but not mummy lords) for 24 hours.
- **Rotting Fist:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 10 (2d6 + 3) bludgeoning damage plus 10 (3d6) necrotic damage. If the target is a creature  it makes a DC 13 Constitution saving throw. On a failure  it is cursed with Mummy Rot.
}}
```