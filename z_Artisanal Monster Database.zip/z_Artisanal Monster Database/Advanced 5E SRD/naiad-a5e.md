```monsterwide
{{monster,frame,wide
## Naiad
*Medium fey*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 22 (5d8)
**Speed**      :: 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: nature +3, perception +5, stealth +3, survival +5
**Senses**      :: darkvision 60 ft., passive Perception 14
**Languages**   :: Elvish, Sylvan
**CR**          :: 1 (PB +2)
}}
### Traits
- **Magic Resistance:** The naiad has advantage on saving throws against spells and magical effects.
- **Speak with Nature:** The naiad can communicate with beasts and plants.
- **Amphibious:** The naiad can breathe air and water.
### Actions
- **Watery Grasp:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 4 (1d4 + 2) bludgeoning damage  and the target is grappled (escape DC 12). While grappling a creature this way  the naiad can't use Watery Grasp on a different target and can swim at full speed.
}}
```