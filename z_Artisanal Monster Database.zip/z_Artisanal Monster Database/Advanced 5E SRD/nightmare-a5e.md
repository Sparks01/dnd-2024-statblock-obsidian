```monsterwide
{{monster,frame,wide
## Nightmare
*Large Fiend*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 68 (8d10+24)
**Speed**      :: 60 ft. fly 90 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** fire
**Senses**      :: passive Perception 11
**Languages**   :: understands Abyssal, Common, and Infernal but can't speak
**CR**          :: 3 (PB +2)
}}
### Traits
- **Evil:** The nightmare radiates an Evil aura.
- **Fiery Hooves:** The nightmare sheds bright light in a 10-foot radius and dim light for an additional 10 feet. The nightmare leaves charred hoofprints.
- **Fire Resistance:** The nightmare can grant fire resistance to a rider.
### Actions
- **Hooves:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 11 (2d6 + 4) bludgeoning damage plus 7 (2d6) fire damage. If the horse moves at least 20 feet straight towards the target before the attack  the target makes a DC 14 Strength saving throw  falling prone on a failure. The nightmare can move through the space of a prone creature as long as it does not end its turn there.
- **Ethereal Shift (Recharge 5-6):** The nightmare and a rider magically pass from the Ethereal Plane to the Material Plane or vice versa.
}}
```