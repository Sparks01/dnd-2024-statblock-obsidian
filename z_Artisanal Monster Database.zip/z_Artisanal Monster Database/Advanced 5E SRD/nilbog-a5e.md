```monsterwide
{{monster,frame,wide
## Nilbog
*Small humanoid*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 14 (4d6)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +3
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Common, Goblin
**CR**          :: 1 (PB +2)
}}
### Traits
- **Opposite Nature:** Normal damage heals the nilbogfor the amount done. Nilbogs can only be harmed/damaged by healing magic. Their skin resists all otherforms of harm. Potions of healing deal acid damage toa nilbog equal to the amount of hit points they wouldnormally heal, and spells that restore hit pointsinstead deal necrotic damage.
### Actions
- **Rat flail:** Melee Weapon Attack: +5 to hit, reach 10 ft., one target. Hit: 9 (3d4 + 1) bludgeoning or piercing damage.
- **Fetid sling:** Ranged Weapon Attack: +3 to hit, range 20/60 ft., one target. Hit: 3(1d6) bludgeoning damage  and the target must make a DC 14 Constitutionsaving throw. On a failure  the target is poisoned for 1minute.
### Bonus Actions
- **Nimble Escape:** The goblin takes the Disengage or Hide action.
}}
```