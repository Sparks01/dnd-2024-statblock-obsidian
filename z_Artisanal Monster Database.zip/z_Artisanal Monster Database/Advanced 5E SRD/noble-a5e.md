```monsterwide
{{monster,frame,wide
## Noble
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 13 (3d8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: deception +4, history +2, insight +3, intimidation +4, performance +4, persuasion +4
**Senses**      :: passive Perception 11
**Languages**   :: any two
**CR**          :: 1/4 (PB +2)
}}
### Actions
- **Rapier:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 5 (1d8 + 1) piercing damage.
### Reactions
- **Parry:** If the noble is wielding a melee weapon and can see their attacker, they add 2 to their AC against one melee attack that would hit them.
}}
```