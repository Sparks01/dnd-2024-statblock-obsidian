```monsterwide
{{monster,frame,wide
## Ochre Jelly
*Large Ooze*
{{stats
{{vitals
**AC**         :: 8
**HP**         :: 45 (6d10+12)
**Speed**      :: 15 ft. climb 15 ft. swim 15 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** acid, lightning, slashing
**Senses**      :: blindsight 60 ft. (blind beyond this radius), passive Perception 8
**Languages**   :: ### Special Abilities
**CR**          :: 2 (PB +2)
}}
### Traits
- **Amorphous:** The jelly can pass through an opening as narrow as 1 inch wide without squeezing.
- **Spider Climb:** The jelly can use its climb speed even on difficult surfaces and upside down on ceilings.
- **Sunlight Sensitivity:** While in sunlight, the jelly has disadvantage on attack rolls.
- **Ooze Nature:** An ooze doesnt require air or sleep.
### Actions
- **Pseudopod:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 9 (2d6 + 2) bludgeoning damage plus 3 (1d6) acid damage  and the target is grappled (escape DC 12). A grappled target takes 3 (1d6) acid damage at the start of each of the jellys turns.
### Reactions
- **Split:** When a Medium or larger jelly with at least 10 hit points is subjected to lightning or slashing damage, it splits into two jellies that are each one size smaller, freeing any grappled targets. Each new jelly has half the originals hit points (rounded down).
}}
```