```monsterwide
{{monster,frame,wide
## Ork Urk
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 45 (6d8+18)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +4, intimidation +3, perception +2, survival +2
**Senses**      :: passive Perception 12
**Languages**   :: any one
**CR**          :: 2 (PB +2)
}}
### Traits
- **Bloodied Frenzy:** While the berserker is bloodied, they make all attacks with advantage and all attacks against them are made with advantage.
- **Unarmored Defense:** The berserkers AC equals 10 + their Dexterity modifier + their Constitution modifier.
### Actions
- **Multiattack:** The berserker attacks twice.
- **Greataxe:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 8 (1d12 + 2) slashing damage.
- **Handaxe:** Melee or Ranged Weapon Attack: +4 to hit, reach 5 ft or range 20/60 ft., one target. Hit: 5 (1d6 + 2) slashing damage.
- **Aggressive Charge:** The urk moves up to their Speed towards an enemy they can see or hear.
- **Warriors who fight on the front lines of an orc war horde gain a special title: urk, meaning doomed:**  Other orc warriors treat urks with the deference due the sacred nature of their rage and sacrifice.
}}
```