```monsterwide
{{monster,frame,wide
## Owl
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 1 (1d4-1)
**Speed**      :: 5 ft. fly 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +3
**Senses**      :: darkvision 120 ft., passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Flyby:** The owl doesnt provoke opportunity attacks when it flies out of a creatures reach.
- **Keen Hearing and Sight:** The owl has advantage on Perception checks that rely on hearing and sight.
### Actions
- **Talons:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 1 slashing damage. If this damage would reduce a Small or larger target to 0 hit points  the target takes no damage from this attack.
}}
```