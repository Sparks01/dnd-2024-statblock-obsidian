```monsterwide
{{monster,frame,wide
## Owlbear
*Large Monstrosity*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 59 (7d10+21)
**Speed**      :: 40 ft. climb 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3, stealth +3
**Senses**      :: darkvision 60 ft., passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 3 (PB +2)
}}
### Traits
- **Keen Sight and Smell:** The owlbear has advantage on Perception checks that rely on sight or smell.
### Actions
- **Multiattack:** The owlbear attacks with its beak and claws.
- **Beak:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 9 (1d10 + 4) piercing damage.
- **Claws:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 13 (2d8 + 4) slashing damage.
}}
```