```monsterwide
{{monster,frame,wide
## Panther
*Medium Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 13 (3d8)
**Speed**      :: 50 ft. climb 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +4, stealth +4
**Senses**      :: darkvision 30 ft., passive Perception 14
**Languages**   :: ### Special Abilities
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Keen Smell:** The panther has advantage on Perception checks that rely on smell.
### Actions
- **Claws:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 4 (1d4+2) slashing damage. If the panther moves at least 20 feet straight towards the target before the attack  the target makes a DC 12 Strength saving throw  falling prone on a failure.
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 4 (1d4+2) piercing damage.
### Bonus Actions
- **Opportune Bite:** The panther makes a bite attack against a prone creature.
}}
```