```monsterwide
{{monster,frame,wide
## Peryton
*Large Monstrosity*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 34 (4d10+12)
**Speed**      :: 30 ft. fly 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: passive Perception 13
**Languages**   :: understands Common and Sylvan but can't speak
**CR**          :: 2 (PB +2)
}}
### Traits
- **Keen Sight and Smell:** The peryton has advantage on Perception checks that rely on sight or smell.
### Actions
- **Multiattack:** The peryton attacks with its gore and talons.
- **Gore:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 7 (1d8 + 3) piercing damage. This attack scores a critical hit on a roll of 18  19  or 20. If this critical hit reduces a humanoid to 0 hit points  the peryton can use a bonus action to rip the targets heart out with its teeth  killing it.
- **Talons:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 6 (1d6 + 3) piercing damage  or 10 (2d6 + 3) damage if the peryton moves at least 20 feet straight towards the target before the attack.
}}
```