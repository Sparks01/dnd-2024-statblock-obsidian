```monsterwide
{{monster,frame,wide
## Phase Spider
*Large Monstrosity*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 39 (6d10+6)
**Speed**      :: 30 ft. climb 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +4
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 3 (PB +2)
}}
### Traits
- **Ethereal Sight:** The spider can see into both the Material Plane and Ethereal Plane.
- **Spider Climb:** The spider can climb even on difficult surfaces and upside down on ceilings.
- **Web Walker:** The spider ignores movement restrictions imposed by webs.
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 9 (2d6+2) piercing damage and the target makes a DC 11 Constitution saving throw  taking 14 (4d6) poison damage on a failure or half damage on a success. If the poison damage reduces the target to 0 hit points  the target is made stable but poisoned for 1 hour  even if it regains hit points  and it is paralyzed while poisoned in this way.
### Bonus Actions
- **Ethereal Jaunt:** The spider magically shifts from the Material Plane to the Ethereal Plane or vice versa.
}}
```