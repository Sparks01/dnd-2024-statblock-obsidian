```monsterwide
{{monster,frame,wide
## Plesiosaurus
*Large Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 45 (6d10+12)
**Speed**      :: 20 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 11
**Senses**      :: passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 7 (PB +2)
}}
### Traits
- **Hold Breath:** The plesiosaurus can hold its breath for 1 hour.
### Actions
- **Bite:** Melee Weapon Attack: +6 to hit, reach 10 ft., one target. Hit: 15 (2d10 + 4) piercing damage. The target makes a DC 14 Strength saving throw. On a failure  it is pulled up to 5 feet towards the plesiosaurus.
}}
```