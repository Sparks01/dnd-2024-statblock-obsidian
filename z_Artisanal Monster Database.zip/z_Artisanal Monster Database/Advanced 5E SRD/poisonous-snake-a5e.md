```monsterwide
{{monster,frame,wide
## Poisonous Snake
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 2 (1d4)
**Speed**      :: 30 ft. swim 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 10 ft., passive Perception 10
**Senses**      :: blindsight 10 ft., passive Perception 10
**Languages**   :: ### Actions
**CR**          :: 1/8 (PB +2)
}}
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 1 piercing damage and the target makes a DC 10 Constitution saving throw  taking 5 (2d4) poison damage on a failure or half damage on a success.
}}
```