```monsterwide
{{monster,frame,wide
## Pteranodon
*Large Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 30 (4d10+8)
**Speed**      :: 10 ft. fly 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 11
**Senses**      :: passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Flyby:** The pteranodon doesnt provoke an opportunity attack when it flies out of a creatures reach.
### Actions
- **Bite:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 5 (1d8 + 1) piercing damage.
}}
```