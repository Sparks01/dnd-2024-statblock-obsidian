```monsterwide
{{monster,frame,wide
## Quipper
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 1 (1d4-1)
**Speed**      :: 0 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 60 ft., passive Perception 8
**Senses**      :: darkvision 60 ft., passive Perception 8
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Water Breathing:** The quipper breathes only water.
### Actions
- **Bite:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 1 piercing damage. On a hit  the quipper can use a bonus action to make a second bite attack.
}}
```