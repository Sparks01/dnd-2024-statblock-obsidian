```monsterwide
{{monster,frame,wide
## Raptor
*Medium Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 32 (5d8+10)
**Speed**      :: 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 11
**Senses**      :: passive Perception 11
**Languages**   :: ### Special Abilities
**CR**          :: 1 (PB +2)
}}
### Traits
- **Pack Tactics:** The raptor has advantage on attack rolls against a creature if at least one of the raptors allies is within 5 feet of the creature and not incapacitated.
### Actions
- **Claw:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 8 (1d10 + 3) slashing damage. If the target is a Medium or smaller creature  it makes a DC 13 Strength saving throw  falling prone on a failure.
}}
```