```monsterwide
{{monster,frame,wide
## Rat
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 1 (1d4-1)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 30 ft., passive Perception 10
**Senses**      :: darkvision 30 ft., passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Keen Smell:** The rat has advantage on Perception checks that rely on smell.
### Actions
- **Bite:** Melee Weapon Attack: +1 to hit, reach 5 ft., one target. Hit: 1 piercing damage.
}}
```