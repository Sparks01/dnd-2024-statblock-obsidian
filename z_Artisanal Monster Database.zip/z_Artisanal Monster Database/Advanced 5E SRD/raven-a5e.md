```monsterwide
{{monster,frame,wide
## Raven
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 1 (1d4-1)
**Speed**      :: 10 ft. fly 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: passive Perception 13
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Mimicry:** The raven can imitate sounds it hears frequently, such as a simple phrase or an animal noise. Recognizing the sounds as imitation requires a DC 10 Insight check.
### Actions
- **Beak:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 1 piercing damage. If this damage would reduce a Small or larger target to 0 hit points  the target takes no damage from this attack.
}}
```