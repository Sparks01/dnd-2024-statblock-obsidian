```monsterwide
{{monster,frame,wide
## Red Dragon Wyrmling
*Medium Dragon*
{{stats
{{vitals
**AC**         :: 17
**HP**         :: 75 (10d8+30)
**Speed**      :: 30 ft. climb 30 ft. fly 60 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: intimidation +4, perception +2, stealth +3
**Senses**      :: blindsight 10 ft., darkvision 60 ft., passive Perception 12
**Languages**   :: Draconic
**CR**          :: 4 (PB +2)
}}
### Traits
- **Volcanic Tyrant:** The dragon is immune to the effects of poisonous gases caused by volcanic environments. It also ignores difficult terrain caused by lava.
### Actions
- **Bite:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 20 (3d10 + 4) piercing damage.
- **Fire Breath (Recharge 5-6):** The dragon exhales a blast of fire in a 15-foot cone. Each creature in that area makes a DC 15 Dexterity saving throw  taking 24 (7d6) fire damage on a failed save or half damage on a success.
}}
```