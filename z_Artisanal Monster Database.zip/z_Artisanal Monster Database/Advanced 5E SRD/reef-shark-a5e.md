```monsterwide
{{monster,frame,wide
## Reef Shark
*Medium Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 22 (4d8+4)
**Speed**      :: 0 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2
**Senses**      :: blindsight 30 ft., passive Perception 12
**Languages**   :: ### Special Abilities
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Pack Tactics:** The shark has advantage on attack rolls against a creature if at least one of the sharks allies is within 5 feet of the creature and not incapacitated.
- **Water Breathing:** The shark breathes only water.
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 6 (1d8+2) piercing damage.
}}
```