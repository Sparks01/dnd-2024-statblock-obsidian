```monsterwide
{{monster,frame,wide
## Rhinoceros
*Large Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 45 (6d10+12)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 11
**Senses**      :: passive Perception 11
**Languages**   :: ### Actions
**CR**          :: 2 (PB +2)
}}
### Actions
- **Gore:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 14 (2d8+5) bludgeoning damage. If the rhinoceros moves at least 20 feet straight towards the target before the attack  the attack deals an extra 4 (1d8) bludgeoning damage and the target makes a DC 15 Strength saving throw  falling prone on a failure.
}}
```