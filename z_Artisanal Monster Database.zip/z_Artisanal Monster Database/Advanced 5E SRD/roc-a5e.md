```monsterwide
{{monster,frame,wide
## Roc
*Gargantuan Beast*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 232 (15d20+75)
**Speed**      :: 20 ft. fly 120 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +6
**Senses**      :: passive Perception 16
**Languages**   :: ### Special Abilities
**CR**          :: 13 (PB +2)
}}
### Traits
- **Keen Sight:** The roc has advantage on Perception checks that rely on sight.
- **Siege Monster:** The roc deals double damage to objects and structures.
### Actions
- **Multiattack:** The roc attacks once with its beak and once with its talons  or makes a beak attack and drops a grappled creature or held object.
- **Beak:** Melee Weapon Attack: +14 to hit, reach 10 ft., one target. Hit: 23 (4d6+9) piercing damage.
- **Talons:** Melee Weapon Attack: +14 to hit, reach 5 ft., one target. Hit: 23 (4d6+9) slashing damage  and the target is grappled (escape DC 22). Until this grapple ends  the target is restrained  and the roc can't attack a different target with its talons.
### Reactions
- **Retributive Strike:** When a creature the roc can see hits it with a melee weapon attack, the roc makes a beak attack against its attacker.
}}
```