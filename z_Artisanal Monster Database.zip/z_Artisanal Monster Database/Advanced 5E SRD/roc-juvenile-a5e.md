```monsterwide
{{monster,frame,wide
## Roc Juvenile
*Huge Beast*
{{stats
{{vitals
**AC**         :: 14
**HP**         :: 147 (14d12+56)
**Speed**      :: 25 ft. fly 100 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +4
**Senses**      :: passive Perception 14
**Languages**   :: ### Special Abilities
**CR**          :: 8 (PB +2)
}}
### Traits
- **Keen Sight:** The roc has advantage on Perception checks that rely on sight.
### Actions
- **Multiattack:** The roc attacks once with its beak and once with its talons  or makes a beak attack and drops a grappled creature or held object.
- **Beak:** Melee Weapon Attack: +9 to hit, reach 10 ft., one target. Hit: 16 (3d6+6) piercing damage.
- **Talons:** Melee Weapon Attack: +9 to hit, reach 5 ft., one target. Hit: 16 (3d6+6) slashing damage  and the target is grappled (escape DC 17). Until this grapple ends  the target is restrained  and the roc can't attack a different target with its talons.
### Reactions
- **Retributive Strike:** When a creature the roc can see hits it with a melee weapon attack, the roc makes a beak attack against its attacker.
}}
```