```monsterwide
{{monster,frame,wide
## Rug of Smothering
*Large Construct*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 45 (7d8+14)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison, psychic
**Senses**      :: blindsight 60 ft. (blind beyond this radius), passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 2 (PB +2)
}}
### Traits
- **Spell-created:** The DC for dispel magic to destroy this creature is 19.
- **False Appearance:** While motionless, the rug is indistinguishable from a normal rug.
### Actions
- **Smother:** Melee Weapon Attack: +5 to hit, reach 5 ft., one Large or smaller creature. Hit: The target is grappled (escape DC 13). Until this grapple ends  the target is restrained and can't breathe. When the rug is dealt damage while it is grappling  it takes half the damage (rounded down) and the other half is dealt to the grappled target. The rug can only have one creature grappled at once.
- **Squeeze:** One creature grappled by the rug takes 10 (2d6 + 3) bludgeoning damage.
}}
```