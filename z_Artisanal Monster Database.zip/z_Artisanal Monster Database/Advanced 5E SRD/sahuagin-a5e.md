```monsterwide
{{monster,frame,wide
## Sahuagin
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 22 (4d8+4)
**Speed**      :: 30 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +3
**Senses**      :: darkvision 120 ft., passive Perception 13
**Languages**   :: Sahuagin
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Blood Frenzy:** The sahuagin has advantage on melee attack rolls against bloodied creatures.
- **Limited Amphibiousness:** The sahuagin can breathe air and water. When breathing air, it must immerse itself in water once every 4 hours or begin to suffocate.
- **Shark Telepathy:** The sahuagin can command any shark within 120 feet of it using magical telepathy.
### Actions
- **Claw:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 5 (1d8 + 1) slashing damage.
- **Trident:** Melee or Ranged Weapon Attack: +3 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 4 (1d6 + 1) piercing damage  or 5 (1d8 + 1) if wielded in two hands in melee.
### Bonus Actions
- **Bite:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 3 (1d4 + 1) piercing damage.
}}
```