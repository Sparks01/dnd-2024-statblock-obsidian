```monsterwide
{{monster,frame,wide
## Sahuagin Champion
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 90 (12d8+36)
**Speed**      :: 40 ft. swim 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +7, intimidation +5, perception +4, stealth +7, survival +4
**Senses**      :: darkvision 120 ft., passive Perception 14
**Languages**   :: Sahuagin
**CR**          :: 5 (PB +2)
}}
### Traits
- **Blood Frenzy:** The sahuagin has advantage on melee attack rolls against creatures that dont have all their hit points.
- **Limited Amphibiousness:** The sahuagin can breathe air and water. When breathing air, it must immerse itself in water once every 4 hours or begin to suffocate.
- **Shark Telepathy:** The sahuagin can command any shark within 120 feet of it using magical telepathy.
### Actions
- **Multiattack:** The sahuagin attacks twice.
- **Claw:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 8 (1d8 + 4) slashing damage.
- **Trident:** Melee or Ranged Weapon Attack: +7 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 7 (1d6 + 4) piercing damage  or 8 (1d8 + 4) if wielded in two hands in melee.
### Bonus Actions
- **Bite:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 6 (1d4 + 4) piercing damage.
}}
```