```monsterwide
{{monster,frame,wide
## Sand Worm
*Gargantuan Monstrosity*
{{stats
{{vitals
**AC**         :: 18
**HP**         :: 247 (15d20+90)
**Speed**      :: 50 ft. burrow 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +5
**Senses**      :: blindsight 30 ft., tremorsense 60 ft., passive Perception 15
**Languages**   :: ### Special Abilities
**CR**          :: 15 (PB +2)
}}
### Traits
- **Tunneler:** The worm can tunnel through earth and solid rock, leaving behind a 10-foot-diameter tunnel.
- **Sand Cascade:** When the worm emerges from under sand, each creature within 30 feet makes a DC 24 Constitution saving throw, falling prone on a failure.
### Actions
- **Multiattack:** The worm attacks two different targets with its bite and its tail stinger.
- **Bite:** Melee Weapon Attack: +14 to hit, reach 10 ft., one target. Hit: 25 (3d10 + 9) piercing damage. If the target is a Large or smaller creature  it makes a DC 19 Dexterity saving throw. On a failure  the target is swallowed. A swallowed creature is blinded and restrained  it has total cover from attacks from outside the worm  and it takes 24 (7d6) acid damage at the start of each of the worms turns.
- **If a swallowed creature deals 35 or more damage to the worm in a single turn, or if the worm dies, the worm vomits up all swallowed creatures:** 
- **Tail Stinger:** Melee Weapon Attack: +14 to hit, reach 10 ft., one creature. Hit: 19 (3d6 + 9) piercing damage  and the target makes a DC 19 Constitution saving throw  taking 42 (12d6) poison damage on a failed save or half damage on a success.
### Reactions
- **Fighting Retreat:** When a creature makes an opportunity attack on the worm, the worm attacks with either its bite or its tail stinger.
}}
```