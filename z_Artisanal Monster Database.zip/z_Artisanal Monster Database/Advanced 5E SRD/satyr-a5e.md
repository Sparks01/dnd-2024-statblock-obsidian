```monsterwide
{{monster,frame,wide
## Satyr
*Medium fey*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 22 (5d8)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: perception +2, performance +5, stealth +4
**Senses**      :: passive Perception 12
**Languages**   :: Common, Elvish, Sylvan
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Magic Resistance:** The satyr has advantage on saving throws against spells and other magical effects.
### Actions
- **Ram:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 4 (1d6 + 1) bludgeoning damage  or 8 (2d6 + 1) bludgeoning damage if the satyr moves at least 20 feet straight towards the target before the attack.
- **Rapier:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 6 (1d8 + 2) piercing damage.
- **Shortbow:** Ranged Weapon Attack: +4 to hit, range 80/320 ft., one target. Hit: 5 (1d6 + 2) piercing damage.
- **Dance Tune:** Each humanoid  fey  or giant within 30 feet that can hear the satyr makes a DC 13 Wisdom saving throw. On a failure  it must dance until the beginning of the satyrs next turn. While dancing  its movement speed is halved  and it has disadvantage on attack rolls. Satyrs dont suffer the negative consequences of dancing. If a creatures saving throw is successful or the effect ends for it  it is immune to any satyrs Dance Tune for 24 hours. This is a magical charm effect.
- **Lullaby:** Each humanoid or giant within 30 feet that can hear the satyr makes a DC 13 Constitution saving throw. On a failure  it falls asleep. It wakes up if a creature uses an action to wake it or if the satyr ends a turn without using its action to continue the lullaby. If a creatures saving throw is successful or the effect ends for it  it is immune to any satyrs Lullaby for 24 hours. This is a magical charm effect.
}}
```