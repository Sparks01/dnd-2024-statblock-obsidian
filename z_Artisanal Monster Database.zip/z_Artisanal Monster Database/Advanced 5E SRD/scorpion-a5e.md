```monsterwide
{{monster,frame,wide
## Scorpion
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 1 (1d4-1)
**Speed**      :: 10 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** blindsight 10 ft., passive Perception 9
**Senses**      :: blindsight 10 ft., passive Perception 9
**Languages**   :: ### Actions
**CR**          :: 0 (PB +2)
}}
### Actions
- **Sting:** Melee Weapon Attack: +2 to hit, reach 5 ft., one target. Hit: 1 piercing damage and the target makes a DC 9 Constitution save  taking 4 (1d8) poison damage on a failure or half damage on a success.
}}
```