```monsterwide
{{monster,frame,wide
## Shadow Elf Champion Warrior
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 90 (12d8+36)
**Speed**      :: 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +7, intimidation +5, perception +4, stealth +7, survival +4
**Senses**      :: passive Perception 14, darkvision 120 ft.
**Languages**   :: any one
**CR**          :: 5 (PB +2)
}}
### Traits
- **Shadow Elf Spellcasting:** The warriors spellcasting ability is Charisma (spell save DC 13). The warrior can innately cast the following spells, requiring no material components:
*At Will:* _dancing lights_ 
*1/day each:* _darkness, faerie fire_
### Actions
- **Multiattack:** The warrior attacks twice.
- **Shortsword:** Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 7 (1d6 + 4) piercing damage. As part of this attack  the warrior can poison the blade  causing the attack to deal an extra 7 (2d6) poison damage.
- **Hand Crossbow:** Ranged Weapon Attack: +7 to hit, range 30/120 ft., one target. Hit: 7 (1d6 + 4) piercing damage. If the target is a creature  it makes a DC 13 Constitution saving throw. On a failure  the target is poisoned for 1 hour. If it fails the saving throw by 5 or more  it falls unconscious until it is no longer poisoned  it takes damage  or a creature takes an action to shake it awake.
}}
```