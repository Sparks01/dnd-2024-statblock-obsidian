```monsterwide
{{monster,frame,wide
## Shadow Elf Warrior
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 11 (2d8+2)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: athletics +3, stealth +3, perception +4, survival +4
**Senses**      :: passive Perception 14, darkvision 120 ft.
**Languages**   :: any one
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Shadow Elf Spellcasting:** The warriors spellcasting ability is Wisdom (spell save DC 12). The warrior can innately cast the following spells, requiring no material components:
*At Will:* _dancing lights_ 
*1/day each:* _darkness, faerie fire_
### Actions
- **Shortsword:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 4 (1d6 + 1) piercing damage.
- **Hand Crossbow:** Ranged Weapon Attack: +3 to hit, range 30/120 ft., one target. Hit: 4 (1d6 + 1) piercing damage. If the target is a creature  it makes a DC 13 Constitution saving throw. On a failure  the target is poisoned for 1 hour. If it fails the saving throw by 5 or more  it falls unconscious until it is no longer poisoned  it takes damage  or a creature takes an action to shake it awake.
}}
```