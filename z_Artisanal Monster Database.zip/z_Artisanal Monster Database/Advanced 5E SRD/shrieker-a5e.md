```monsterwide
{{monster,frame,wide
## Shrieker
*Medium Plant*
{{stats
{{vitals
**AC**         :: 5
**HP**         :: 13 (3d8)
**Speed**      :: 0 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** fire
**Senses**      :: blindsight 30 ft. (blind beyond this radius), passive Perception 6
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **False Appearance:** While motionless, the shrieker is indistinguishable from a normal fungus.
### Reactions
- **Shriek:** If the shrieker perceives a creature within 30 feet  or if an area of bright light is within 30 feet  it shrieks loudly and continuously. The shriek is audible within 300 feet. The shrieker continues to shriek for 1 minute after the creature or light has moved away.
}}
```