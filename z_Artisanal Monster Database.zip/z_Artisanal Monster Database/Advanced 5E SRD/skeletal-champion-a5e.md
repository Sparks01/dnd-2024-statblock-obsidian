```monsterwide
{{monster,frame,wide
## Skeletal Champion
*Medium Undead*
{{stats
{{vitals
**AC**         :: 15
**HP**         :: 58 (9d8+18)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** bludgeoning
**Senses**      :: darkvision 60 ft., passive Perception 9
**Languages**   :: understands the languages it knew in life but can't speak
**CR**          :: 3 (PB +2)
}}
### Traits
- **Undead Nature:** A skeleton doesnt require air, sustenance, or sleep.
### Actions
- **Multiattack:** The skeleton makes two melee attacks.
- **Longsword:** Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 7 (1d8 + 3) slashing damage.
- **Heavy Crossbow:** Ranged Weapon Attack: +5 to hit, range 100/400 ft., one target. Hit: 8 (1d10 + 3) piercing damage.
### Reactions
- **Shielding Riposte:** When a creature within the skeletons reach misses with a melee attack against the skeleton or a creature within 5 feet, the skeleton makes a longsword attack against the attacker. The skeleton must be wielding a longsword to use this reaction.
}}
```