```monsterwide
{{monster,frame,wide
## Skeletal Tyrannosaurus Rex
*Huge Undead*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 126 (11d12+55)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** bludgeoning
**Senses**      :: darkvision 60 ft., passive Perception 9
**Languages**   :: ### Special Abilities
**CR**          :: 8 (PB +2)
}}
### Traits
- **Undead Nature:** A skeleton doesnt require air, sustenance, or sleep.
### Actions
- **Multiattack:** The skeleton makes a bite attack and a tail attack against two different targets.
- **Bite:** Melee Weapon Attack: +9 to hit, reach 10 ft., one target. Hit: 25 (3d12 + 6) piercing damage. If the target is a creature  it is grappled (escape DC 17). Until this grapple ends  the skeleton can't bite a different creature and it has advantage on bite attacks against the grappled creature.
- **Tail:** Melee Weapon Attack: +9 to hit, reach 10 ft., one target. Hit: 19 (3d8 + 6) bludgeoning damage.
}}
```