```monsterwide
{{monster,frame,wide
## Skeletal Warhorse
*Large Undead*
{{stats
{{vitals
**AC**         :: 11
**HP**         :: 30 (4d10+8)
**Speed**      :: 50 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** bludgeoning
**Senses**      :: darkvision 60 ft., passive Perception 9
**Languages**   :: ### Special Abilities
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Undead Nature:** A skeleton doesnt require air, sustenance, or sleep.
### Actions
- **Hooves:** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 7 (1d6 + 4) bludgeoning damage. If the skeleton moves at least 20 feet straight towards the target before the attack  the target makes a DC 14 Strength saving throw  falling prone on a failure.
}}
```