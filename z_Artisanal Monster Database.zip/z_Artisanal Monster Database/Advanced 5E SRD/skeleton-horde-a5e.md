```monsterwide
{{monster,frame,wide
## Skeleton Horde
*Large Undead*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 65 (10d8+20)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Vulnerabilities:** bludgeoning
**Senses**      :: darkvision 60 ft., passive Perception 9
**Languages**   :: understands the languages it knew in life but can't speak
**CR**          :: 4 (PB +2)
}}
### Traits
- **Undead Nature:** A skeleton doesnt require air, sustenance, or sleep.
### Actions
- **Shortsword:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 27 (5d6 + 10) piercing damage  or half damage if the horde is bloodied.
- **Shortbow:** Ranged Weapon Attack: +4 to hit, range 80/320 ft., one target. Hit: 27 (5d6 + 10) piercing damage  or half damage if the horde is bloodied.
}}
```