```monsterwide
{{monster,frame,wide
## Spark Mephit
*Small elemental*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 17 (5d6)
**Speed**      :: 30 ft. fly 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** lightning, poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Auran, Ignan
**CR**          :: 1/2 (PB +2)
}}
### Traits
- **Death Burst:** When the mephit dies, its Spark Form recharges, and the mephit uses it before it dies.
- **Elemental Nature:** A mephit doesnt require air, sustenance, or sleep.
### Actions
- **Claws:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 4 (1d4 + 2) slashing damage plus 2 (1d4) lightning damage.
- **Spark Form (Recharge 6):** The mephit transforms into an arc of lightning and flies up to 20 feet without provoking opportunity attacks. During this movement  the mephit can pass through other creatures spaces. Whenever it moves through another creatures space for the first time during this movement  that creature makes a DC 12 Dexterity saving throw  taking 5 (2d4) lightning damage on a failed save or half damage on a success. The mephit then reverts to its original form.
- **Faerie Flame (1/Day):** Each creature within 10 feet of the mephit makes a DC 11 Dexterity saving throw. On a failure  the creature is magically outlined in blue light for 1 minute. While outlined  the creature gains no benefit from being invisible and attack rolls against it are made with advantage.
}}
```