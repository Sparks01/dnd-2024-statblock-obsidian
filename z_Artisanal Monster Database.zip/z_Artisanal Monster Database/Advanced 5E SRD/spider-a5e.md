```monsterwide
{{monster,frame,wide
## Spider
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 1 (1d4-1)
**Speed**      :: 20 ft. climb 20 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: stealth +4
**Senses**      :: darkvision 30 ft., passive Perception 10
**Languages**   :: ### Special Abilities
**CR**          :: 0 (PB +2)
}}
### Traits
- **Spider Climb:** The spider can climb even on difficult surfaces and upside down on ceilings.
- **Web Sense:** While touching a web, the spider knows the location of other creatures touching that web.
- **Web Walker:** The spider ignores movement restrictions imposed by webs.
### Actions
- **Bite:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 1 piercing damage and the target makes a DC 9 Constitution saving throw  taking 2 (1d4) poison damage on a failure.
}}
```