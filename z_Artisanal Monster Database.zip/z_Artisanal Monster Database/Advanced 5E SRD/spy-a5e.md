```monsterwide
{{monster,frame,wide
## Spy
*Medium humanoid*
{{stats
{{vitals
**AC**         :: 12
**HP**         :: 27 (6d8)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: deception +4, insight +4, investigation +3, perception +4, persuasion +4, sleight +0, stealth +4
**Senses**      :: passive Perception 14
**Languages**   :: any two
**CR**          :: 1 (PB +2)
}}
### Traits
- **Sneak Attack (1/Turn):** The cutthroat deals an extra 7 (2d6) damage when they hit with a weapon attack while they have advantage on the attack, or when the cutthroats target is within 5 feet of an ally of the cutthroat while the cutthroat doesnt have disadvantage on the attack.
### Actions
- **Shortsword:** Melee Weapon Attack: +4 to hit, reach 5 ft., one target. Hit: 5 (1d6 + 2) piercing damage.
- **Hand Crossbow:** Ranged Weapon Attack: +4 to hit, range 30/120 ft., one target. Hit: 5 (1d6 + 2) piercing damage.
### Bonus Actions
- **Cunning Action:** The cutthroat takes the Dash, Disengage, Hide, or Use an Object action.
- **Rapid Attack:** The cutthroat attacks with their shortsword.
}}
```