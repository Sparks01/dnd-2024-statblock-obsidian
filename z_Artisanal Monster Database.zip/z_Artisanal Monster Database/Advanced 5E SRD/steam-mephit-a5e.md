```monsterwide
{{monster,frame,wide
## Steam Mephit
*Small elemental*
{{stats
{{vitals
**AC**         :: 10
**HP**         :: 21 (6d6)
**Speed**      :: 30 ft. fly 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** fire, poison
**Senses**      :: darkvision 60 ft., passive Perception 10
**Languages**   :: Aquan, Ignan
**CR**          :: 1/4 (PB +2)
}}
### Traits
- **Death Burst:** When the mephit dies, it explodes into steam. Each creature within 5 feet makes a DC 10 Constitution saving throw, taking 4 (1d8) fire damage on a failed save.
- **Elemental Nature:** A mephit doesnt require air, sustenance, or sleep.
### Actions
- **Claws:** Melee Weapon Attack: +3 to hit, reach 5 ft., one target. Hit: 2 (1d4) slashing damage plus 2 (1d4) fire damage.
- **Blurred Form (1/Day, Bloodied Only):** The mephit uses magical illusion to blur its form. For 1 minute  attacks against the mephit are made with disadvantage.
- **Steam Breath (1/Day):** The mephit exhales a 15-foot cone of steam. Each creature in the area makes a DC 10 Constitution saving throw  taking 4 (1d8) fire damage on a failed save or half damage on a success.
}}
```