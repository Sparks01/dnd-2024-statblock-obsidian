```monsterwide
{{monster,frame,wide
## Stegosaurus
*Huge Beast*
{{stats
{{vitals
**AC**         :: 16
**HP**         :: 63 (6d12+24)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** passive Perception 11
**Senses**      :: passive Perception 11
**Languages**   :: ### Actions
**CR**          :: 3 (PB +2)
}}
### Actions
- **Tail:** Melee Weapon Attack: +6 to hit, reach 10 ft., one target. Hit: 17 (3d8 + 4) piercing damage. If the target is a Large or smaller creature  it makes a DC 14 Strength saving throw. On a failure  it is knocked prone.
}}
```