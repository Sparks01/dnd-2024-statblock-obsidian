```monsterwide
{{monster,frame,wide
## Stirge
*Tiny Beast*
{{stats
{{vitals
**AC**         :: 13
**HP**         :: 2 (1d4)
**Speed**      :: 10 ft. fly 40 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Senses:** darkvision 60 ft., passive Perception 9
**Senses**      :: darkvision 60 ft., passive Perception 9
**Languages**   :: ### Actions
**CR**          :: 1/8 (PB +2)
}}
### Actions
- **Proboscis:** Melee Weapon Attack: +5 to hit, reach 5 ft., one creature. Hit: 1 piercing damage  and the stirge attaches to the target. A creature can use an action to detach it  and it can detach itself as a bonus action.
- **Blood Drain:** The stirge drains blood from the creature it is attached to. The creature loses 4 (1d8) hit points. After the stirge has drained 8 hit points  it detaches itself and can't use Blood Drain again until it finishes a rest.
}}
```