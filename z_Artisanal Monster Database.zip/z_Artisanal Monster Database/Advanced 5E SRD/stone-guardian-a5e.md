```monsterwide
{{monster,frame,wide
## Stone Guardian
*Large Construct*
{{stats
{{vitals
**AC**         :: 17
**HP**         :: 178 (17d10+85)
**Speed**      :: 30 ft.
}}
{{tables
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Str| 10|  +0  |  +0  |
|Int| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Dex| 10|  +0  |  +0  |
|Wis| 10|  +0  |  +0  |
|   |   |  MOD | SAVE |
|:--|:-:|:----:|:----:|
|Con| 10|  +0  |  +0  |
|Cha| 10|  +0  |  +0  |
}}
**Skills**     :: - **Damage Immunities:** poison, psychic; damage from nonmagical, non-adamantine weapons
**Senses**      :: darkvision 120 ft., passive Perception 11
**Languages**   :: understands the languages of its creator but can't speak
**CR**          :: 10 (PB +2)
}}
### Traits
- **Immutable Form:** The guardian is immune to any effect that would alter its form.
- **Magic Resistance:** The guardian has advantage on saving throws against spells and magical effects.
- **Constructed Nature:** Guardians dont require air, sustenance, or sleep.
### Actions
- **Multiattack:** The guardian attacks twice with its slam.
- **Slam:** Melee Weapon Attack: +10 to hit, reach 5 ft., one target. Hit: 19 (3d8 + 6) bludgeoning damage.
- **Rock:** Ranged Weapon Attack: +10 to hit, range 60/240 ft., one target. Hit: 30 (7d6 + 6) bludgeoning damage. The target makes a DC 18 Strength saving throw  falling prone on a failure.
### Bonus Actions
- **Slow (Recharge 5-6):** The guardian targets one or more creatures within 30 feet. Each target makes a DC 17 Wisdom saving throw. On a failure, the target is slowed for 1 minute. A target can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success.
}}
```